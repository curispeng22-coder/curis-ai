# Product Fact Source Registry

Machine-discovered candidates from the full semantic-readable manifest. Name/header/status fields are extracted literally where possible. Inclusion means “possible product fact source,” not current authority. `Pointer reference` checks only direct links in the frozen Product Document Pointer. Supersession requires explicit in-file evidence and remains UNKNOWN unless listed by filename/context.

| File | Declared Authority | Status | Disposition | Direct Pointer ref | Explicit supersede signal | Current input? |
|---|---|---|---|---|---|---|
| `Curis-Professional-Workspace-Operating-Reconciliation-CEO-Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `Talent_Market_Product_Map.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_FIGMA_MAKE_INPUT_MANIFEST.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `HANDOFF_DESIGN_AUTHORITY_2026-08-17.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `CONTENT_GROWTH_INDEPENDENT_RED_TEAM_REVIEW.md` | **REVIEW** | **REVIEW / STOP FOR CEO REVIEW** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `Curis_Product_Rethink_Reasoning.md` | UNKNOWN | REVIEW REQUIRED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_FIRST_RUN_AND_BUSINESS_ENTRY_MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_INDEPENDENT_RED_TEAM_SECOND_PASS.md` | **REVIEW** | **REVIEW / STOP FOR CEO REVIEW** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_XHS_INTERACTIVE_PROTOTYPE_FROZEN_COMPLIANCE_AUDIT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `README.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `Talent_Market_Integration_Contract.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_FIGMA_MAKE_CURRENT_DESIGN_CONTEXT_PACK.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_FINAL_PRE_IA_RED_TEAM_VERIFICATION.md` | **REVIEW** | **REVIEW / STOP FOR CEO REVIEW** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_VISUAL_DESIGN_CHATGPT_HANDOFF_PACK.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `Curis_Product_Master_Map_v2.0.md` | UNKNOWN | REVIEW REQUIRED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `AGENTS.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `PROJECT_HANDOFF.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_PRODUCT_REALITY_ALIGNMENT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/views-craft.js` | UNKNOWN | '状态', title: '标题', purpose: '目的', events: '关键事件', emotion: '情绪推进', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_review_batch_check.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/TAGS_WORKSPACE_REVISION_REPORT.md` | RESEARCH ｜ Status: Review ｜ 本轮不升级任何 Current Authority | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CODEX_WRITING_CONTINUITY_CONTRACT.md` | RESEARCH | Review | CEO同意本轮实现方向；独立HTML候选，不修改Current Authority | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CODEX_FLOW_REVISION_ISSUE.md` | RESEARCH | Review | CEO授权独立HTML修改；非正式产品Authority | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CODEX_BOOK_EDITOR_REVIEW.md` | EVIDENCE | Review | 原型修改已验证，等待CEO体验；不是模型能力或正式产品验收 | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/README.md` | RESEARCH ｜ Status: Review ｜ 本轮不升级任何 Current Authority | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/data.js` | RESEARCH（本轮探索自有数据，不进入 Curis Authority） | '连载中', startedAt: '2026-06-02', positioning: '单元剧外壳 + 主线长线；每 2–3 章一个可独立成立的小案，同时推 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CODEX_REVIEW_RULES_VERIFICATION.md` | EVIDENCE | Review | Awaiting CEO Review | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CODEX_FLOW_REVISION_REPORT.md` | REVIEW | Review | 已实现独立原型候选，等待 CEO 体验；不等于正式产品验收 | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CODEX_WRITING_CONTINUITY_REVIEW.md` | EVIDENCE | Review | Prototype revision complete; awaiting CEO review. Not Product Authority or Runtime acceptance. | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/WRITING_OPERATING_INTELLIGENCE_REVISION_NOTES.md` | RESEARCH | Review | 候选原型已达到本轮 CEO Review 入口；未升级为当前 Product Truth。 | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_round5_author_journey_2026-09-22/src/views-craft.js` | UNKNOWN | '状态', title: '标题', purpose: '目的', events: '关键事件', emotion: '情绪推进', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_round5_author_journey_2026-09-22/src/TAGS_WORKSPACE_REVISION_REPORT.md` | RESEARCH ｜ Status: Review ｜ 本轮不升级任何 Current Authority | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_round5_author_journey_2026-09-22/src/README.md` | RESEARCH ｜ Status: Review ｜ 本轮不升级任何 Current Authority | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_round5_author_journey_2026-09-22/src/data.js` | RESEARCH（本轮探索自有数据，不进入 Curis Authority） | '连载中', startedAt: '2026-06-02', positioning: '单元剧外壳 + 主线长线；每 2–3 章一个可独立成立的小案，同时推 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_authorflow_2026-09-21/src/views-craft.js` | UNKNOWN | '状态', title: '标题', purpose: '目的', events: '关键事件', emotion: '情绪推进', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_authorflow_2026-09-21/src/README.md` | RESEARCH ｜ Status: Review ｜ 本轮不升级任何 Current Authority | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_authorflow_2026-09-21/src/data.js` | RESEARCH（本轮探索自有数据，不进入 Curis Authority） | '连载中', startedAt: '2026-06-02', positioning: '单元剧外壳 + 主线长线；每 2–3 章一个可独立成立的小案，同时推 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_evidence/CEO_REVIEW_INDEX.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_book_editor_2026-09-22/views-craft.js` | UNKNOWN | '状态', title: '标题', purpose: '目的', events: '关键事件', emotion: '情绪推进', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CHATGPT_REVIEW_2026-09-23/CEO_REVIEW_SCREENSHOT_INDEX.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CHATGPT_REVIEW_2026-09-23/IMPLEMENTATION_VERIFICATION.md` | EVIDENCE | Review | Awaiting CEO / ChatGPT Review | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/CHATGPT_REVIEW_2026-09-23/CHATGPT_REVIEW_BRIEF.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_codex_flow_2026-09-22/views-craft.js` | UNKNOWN | '状态', title: '标题', purpose: '目的', events: '关键事件', emotion: '情绪推进', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_codex_flow_2026-09-22/README.md` | RESEARCH ｜ Status: Review ｜ 本轮不升级任何 Current Authority | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_inline_2026-09-22/views-craft.js` | UNKNOWN | '状态', title: '标题', purpose: '目的', events: '关键事件', emotion: '情绪推进', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_revision_2026-09-21/README.md` | RESEARCH ｜ Status: Review ｜ 本轮不升级任何 Current Authority | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `WRITING_BUSINESS_HTML_EXPLORATION/_backup_pre_revision_2026-09-21/src/data.js` | RESEARCH（本轮探索自有数据，不进入 Curis Authority） | '连载中', startedAt: '2026-06-02', positioning: '单元剧外壳 + 主线长线；每 2–3 章一个可独立成立的小案，同时推 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_FULL_VISUAL_REEXPRESSION/CEO_REVIEW_NOTES.md` | VISUAL EXPLORATION PROTOTYPE | Ready for CEO Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype.bak/workspace-runtime-software.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype.bak/workspace-runtime-xhs.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype.bak/business.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype.bak/workspace-runtime-department.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype.bak/decision-room.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype.bak/workspace-runtime-shortvideo.html` | UNKNOWN | 'ontrack', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/ceo-office/decision-center.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/ceo-office/company-runtime.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/runtime-orchestration-summary.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/colors_and_type.css` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/docs/ui/curis-ui-v2-handoff.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/docs/ui/curis-ui-v2-secondary-page-contracts.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/execution-tasks.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/brainstorm-results.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/org-employees.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/run-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/analytics-org.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/execution.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/knowledge-dept.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/decision-center.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/knowledge.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/settings-notify.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/company-runtime.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/strategy-room.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/project-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/project-dept.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/department-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/employee-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/task-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/settings-profile.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/org-center.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/brainstorm-session-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/knowledge-project.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/knowledge-company.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/execution-runs.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/ceo-home.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/knowledge-entry-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/capability-model-list.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/analytics-project.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/capability-tool-list.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/skill-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/report-detail.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/settings-brand.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/analytics.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/brainstorm.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/capability-workflow-list.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/brainstorm-active.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/settings.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/analytics-workflow.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/project-center.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/capability-agent-list.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/reports.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/capability-skill-list.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/capability-center.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/design-spec/curis-ui-v2/pages/org-dept.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/app/platform/TalentProductionPanel.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/docs/FRONTEND_HANDOFF.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/terra/RuntimeCapabilitySwitcher.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/workspace/InstalledWorkspaceRuntime.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/runtime/WorkspaceRuntimeView.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/runtime/RuntimeStates.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/runtime/RuntimeProvider.js` | UNKNOWN | "idle", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/rd/RdArtifactReview.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/rd/RdDecisionPackage.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/components/rd/RdResponsibilityHandoff.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/lib/runtimeCapability.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/lib/runtimeApi.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `frontend/ceo-evidence/src/pages/PendingDecisions.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-ceo-desk-visual-competition/runtime-orchestration-summary.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-ceo-desk-visual-competition/direction-reviews.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-first-run-final/runtime-dispatch-manifest.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-first-run-final/runtime-orchestration-summary.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-professional-workspace-validation/runtime-orchestration-summary.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/rd-workspace-default-office/runtime-orchestration-summary.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-professional-workspace-multi-surface/runtime-orchestration-summary.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-professional-workspace-multi-surface/pages/xhs-employee-handoff-1440.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-entry-lifecycle-task-a/runtime-dispatch-manifest.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-entry-lifecycle-task-a/runtime-orchestration-summary.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-entry-lifecycle-task-a/pages/empty-business-space.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-entry-lifecycle-task-a/pages/create-business-entry.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-hifi-v1/pages/business.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-hifi-v1/pages/decision-room.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.design/curis-hifi-v1/pages/workspace-runtime-shortvideo.html` | UNKNOWN | 'ontrack', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/skill_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/ceo_runtime_evidence.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/runtime_capability_context.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/local_project_runtime_target.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/pipeline_runtime.py` | UNKNOWN | str                       # done | escalated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/tool_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/runtime_governance_config.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/company_project_runtime.py` | UNKNOWN | str = "active", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/decision_sink.py` | UNKNOWN | str = "pending"  # "pending" | "resolved" | "cancelled" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/runtime_trace.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/content_workflow_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/assistant_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/business_metrics.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/rd_workflow_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/runtime_governance_config.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/runtime_governance.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/workflow_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/agent_conversion/canonical.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/agent_conversion/sources/product/product-trend-researcher.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/agent_conversion/sources/product/product-feedback-synth.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-08-05-desktop/backend/app/agent_conversion/sources/product/product-behavioral-nudge-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/skill_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/runtime_capability_context.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/tool_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/company_project_runtime.py` | UNKNOWN | str = "active", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/content_workflow_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/rd_workflow_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/workflow_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/agent_conversion/canonical.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/agent_conversion/sources/product/product-trend-researcher.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/agent_conversion/sources/product/product-feedback-synth.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deploy/curis/releases/2026-07-17-isolation/backend/app/agent_conversion/sources/product/product-behavioral-nudge-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_BUSINESS_CODEX_HTML_EXPLORATION/PRODUCT.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_BUSINESS_CODEX_HTML_EXPLORATION/TARGETED_REVISION_NOTES.md` | REVIEW / EVIDENCE | Review | 待 CEO Review；仅 HTML Exploration，不修改 Product Authority。 | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_BUSINESS_CODEX_HTML_EXPLORATION/CEO_REVIEW.md` | EVIDENCE | Review | READY FOR CEO REVIEW; not accepted Product Truth or delivered Runtime | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_BUSINESS_CODEX_HTML_EXPLORATION/MARKET_INTELLIGENCE_REVISION_NOTES.md` | UNKNOWN | Draft · Authority Class: EVIDENCE · 仅用于 HTML 探索验收 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_BUSINESS_CODEX_HTML_EXPLORATION/business.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_BUSINESS_CODEX_HTML_EXPLORATION/business-console-check.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_BUSINESS_CODEX_HTML_EXPLORATION/CEO_REVIEW_SCREENSHOTS_2026-09-23/README_REVIEW.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/analytics-r5.js` | PROTOTYPE MOCK（候选合同的产品表达，不代表 Runtime 已支持） | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/data-r5.js` | PROTOTYPE MOCK（不是当前 Authority，不代表 Runtime 已支持） | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/CONTENT_GROWTH_FULL_WORKSPACE_RECONCILIATION.md` | REVIEW / PROTOTYPE RECONCILIATION | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/REVIEW_ROUND11_UX_FLOW_AUDIT.md` | **REVIEW**（独立复检意见，非 Current Authority） | **Review** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/README.md` | EVIDENCE / PROTOTYPE | Review | COMPLETE — READY FOR CEO REVIEW；仅原型整合，非正式Runtime验收。 | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/production-work.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/CONTENT_GROWTH_FULL_WORKSPACE_RUNTIME_FINDINGS.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/REVIEW_ROUND10_INDEPENDENT.md` | REVIEW | Review | 待 CEO 决定是否修复；**本次只审不改**，未修改任何原型文件、产品 Authority 或 Curis 业务代码 | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/W202_PRODUCTION_WORK_EXPLORATION/exploration.css` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/W202_PRODUCTION_WORK_EXPLORATION/exploration.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/W202_PRODUCTION_WORK_EXPLORATION/README.md` | RESEARCH | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/W202_PRODUCTION_WORK_EXPLORATION/CEO_REVIEW_CAPTURE_V2/CEO_REVIEW_RUNTIME_FINDINGS.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/W202_PRODUCTION_WORK_EXPLORATION/CEO_REVIEW_CAPTURE_V2/CEO_REVIEW_SCREENSHOT_INDEX.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/CEO_REVIEW_CAPTURE/CEO_REVIEW_RUNTIME_FINDINGS.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/CEO_REVIEW_CAPTURE/CEO_REVIEW_SCREENSHOT_INDEX.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/_audit-20260917/INTERACTION_AUDIT.md` | REVIEW | Review | 待 CEO Review；未修改原型或正式 Authority | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_WORKSPACE_HTML_EXPLORATION/CONTENT_GROWTH_FULL_WORKSPACE_CEO_REVIEW/CEO_REVIEW_SCREENSHOT_INDEX.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_PROJECT_WORKSPACE_VISUAL_EXPLORATION/CURIS_PROJECT_WORKSPACE_VISUAL_LANGUAGE_FINDINGS.md` | REVIEW / VISUAL EXPLORATION | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `ai-tech-workspace/pages/handoff.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `desktop/.runtime/build-tools/_pyinstaller_hooks_contrib/stdhooks/hook-nvidia.cuda_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `desktop/.runtime/build-tools/_pyinstaller_hooks_contrib/stdhooks/hook-amazonproduct.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `desktop/.runtime/build-tools/_pyinstaller_hooks_contrib/stdhooks/hook-vtkmodules.vtkDomainsChemistryOpenGL2.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `desktop/.runtime/build-tools/_pyinstaller_hooks_contrib/stdhooks/hook-vtkmodules.vtkFiltersGeometryPreview.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `desktop/.runtime/build-tools/_pyinstaller_hooks_contrib/stdhooks/hook-vtkmodules.vtkDomainsChemistry.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `desktop/.runtime/build-tools/_pyinstaller_hooks_contrib/stdhooks/hook-onnxruntime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `desktop/scripts/build-runtime.sh` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/skill_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/ceo_runtime_evidence.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/runtime_capability_context.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/local_project_runtime_target.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/pipeline_runtime.py` | UNKNOWN | str                       # done | escalated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/tool_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/runtime_governance_config.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/company_project_runtime.py` | UNKNOWN | str = "active", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/decision_sink.py` | UNKNOWN | str = "pending"  # "pending" | "resolved" | "cancelled" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/runtime_trace.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/content_workflow_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/assistant_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/workspace_package_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/business_metrics.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/rd_workflow_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/runtime_governance_config.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/runtime_governance.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/workflow_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/runtime/business_spine.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/api/runtime_foundation_router.py` | UNKNOWN | str = Field(default="idle", pattern=r"^(working|waiting|needs_ceo|completed|fail | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/agent_conversion/external_candidates.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/agent_conversion/production_line.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/agent_conversion/canonical.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/agent_conversion/sources/product/product-trend-researcher.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/agent_conversion/sources/product/product-feedback-synth.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/app/agent_conversion/sources/product/product-behavioral-nudge-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_canonical_business_spine_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_responsibility_routing_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_rd_phase2b_e2e_closure.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_foundation_legacy_adapter.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_foundation_persistence.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_employee_template_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_global_assistant_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_b_layer_runtime_governance.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_materialization_api.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_rd_p7_decision.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_conversation_productization.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_business_department_org_model.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_autonomous_operating_cross_domain_xhs.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_v1_wave1_rd_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_workspace_foundation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_v1_general_workspace_p1_operating_closure.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_talent_capability_productization.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_rd_artifact_review.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_phase1a_company_project_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_workspace_package_runtime_p0.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_ai_secretary_traceability_field_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_foundation_simulation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_foundation_isolation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_ai_secretary_integrity_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_local_project_runtime_target.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_agent_computer_access_runtime_p0.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_trace.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_ai_secretary_refusal_response_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_foundation_state_contracts.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_phase1a_ai_company_runtime_foundation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_three_business_runtime_simulations.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_ai_secretary_sensitive_projection_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_first_arrival_api.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_ceo_runtime_evidence.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_mvp_phase6_s12_runtime_stability.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_d1_unfreeze.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `backend/tests/test_autonomous_cross_surface_multi_work_runtime_proof.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_v1_general_workspace_lifecycle_closure.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_rd_responsibility_handoff.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_v1_general_operating_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_b_layer_decisionsink.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_v1_meeting_room_productization.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_v1_knowledge_library_productization.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_bridge_private_model.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_operating_cycle.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_execution_adapter.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_v1_general_workspace_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_runtime_foundation_api.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_api_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_canonical_business_spine_schema.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_xhs_calendar_note_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_project_runtime_page.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `backend/tests/test_ai_secretary_source_relation_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `shared/product/curis-commercial-system-product-doc.md` | UNKNOWN | Product blueprint for future commercial multi-tenant system. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `shared/architecture/curis-admin-workspace-product-architecture.md` | UNKNOWN | Future blueprint architecture. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/product-governance-principle.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Documentation_Governance_Phase3C3_Delete_Review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Documentation_Governance_Final_Report.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/architecture-review-evoflow-reuse-2026-08-04.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Documentation_Governance_Phase3C2_Asset_Review.md` | UNKNOWN | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/product-development-spec.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/aiearn-content-marketing-final-decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/CURIS_AUTONOMOUS_OPERATION_CODEX_RESEARCH.md` | RESEARCH | Review | CODEX INDEPENDENT TRACK COMPLETE — READY FOR CEO REVIEW | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/CURIS_TEAM_OPERATING_ENGINE_RESEARCH.md` | RESEARCH | Review | READY FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/rd-multi-agent-development/CURIS_RD_MULTI_AGENT_ORCHESTRATION_CONCLUSIONS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/rd-multi-agent-development/details/CURIS_RD_CONTEXT_AND_HANDOFF_MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/rd-multi-agent-development/details/CURIS_RD_PRODUCT_TRANSLATION_IMPACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/rd-multi-agent-development/details/RESEARCH_JOURNAL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/rd-multi-agent-development/details/CURIS_RD_MULTI_AGENT_DEVELOPMENT_STUDY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/CURIS_WRITING_HTML_EXPLORATION_CLOSURE.md` | REVIEW | Review | 产品结构与交互方向获 CEO 接受；仍是 Product Candidate，不升级 Current / Frozen Authority。 | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/WORKBUDDY_WRITING_AUTHOR_FLOW_EMPLOYEE_REVISION.md` | RESEARCH | Review | CEO已授权本轮HTML修改；本任务合同不是Current Authority或验收通过。 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/CURIS_WRITING_FULL_PRODUCT_INTERACTION_DESIGN_CANDIDATE.md` | RESEARCH | Review | INTEGRATED PRODUCT DESIGN CANDIDATE — READY FOR CEO REVIEW；非实现验收。 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/CURIS_WRITING_BUSINESS_RELATIONSHIP_MAP.md` | RESEARCH | Review | CEO ACCEPTED HTML EXPLORATION DIRECTION — RELATIONSHIP CANDIDATE RECONCILED; NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/CURIS_WRITING_BUSINESS_GAP_AUDIT.md` | REVIEW | Review | CEO ACCEPTED HTML EXPLORATION DIRECTION — PRODUCT EXPRESSION GAPS RECONCILED; REAL CAPABILITY GAPS O | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/WORKBUDDY_WRITING_BOOK_CREATIVE_CORE_REVISION.md` | RESEARCH | Review | CEO已授权执行本地HTML修订；不是Authority变更或最终验收 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/WORKBUDDY_WRITING_AUTHOR_JOURNEY_SIMPLIFICATION_REVISION.md` | RESEARCH | Review | CEO授权当前HTML修改；非Current Authority | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/WORKBUDDY_WRITING_TAGS_AND_WORKSPACE_COMPOSITION_REVISION.md` | RESEARCH | Review | CEO AUTHORIZED HTML EXPLORATION INPUT；不是Frozen产品Authority或正式开发验收。 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/CURIS_WRITING_BUSINESS_PRODUCT_STRUCTURE_CANDIDATE.md` | RESEARCH | Review | CEO ACCEPTED HTML EXPLORATION DIRECTION — PRODUCT CANDIDATE RECONCILED; NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/WORKBUDDY_WRITING_BUSINESS_HTML_EXPLORATION_BRIEF.md` | RESEARCH | Review | CEO已接受三份Writing候选作为本轮探索输入；本合同不升级Current Authority。 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/author-flow-reaudit/WRITING_AUTHOR_FLOW_REACCEPTANCE_REVIEW.md` | REVIEW | Review | TARGETED REVISION REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/book-depth-audit/BOOK_CREATIVE_DEPTH_REVIEW.md` | REVIEW | Review | TARGETED REVISION REQUIRED — 创作内核尚不能验收 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/new-book-employee-review/WRITING_NEW_BOOK_EMPLOYEE_REVIEW.md` | REVIEW | Review | TARGETED REVISION REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/openwrite-desktop-study/CURIS_OPENWRITE_DESKTOP_RESEARCH.md` | RESEARCH | Review | CORE WORKFLOW OBSERVED / PREMIUM WORKFLOWS BLOCKED / CURIS ADOPTION CANDIDATES | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/CURIS_YANYUWRITE_REFERENCE_STUDY.md` | RESEARCH | Review | MEMBER WORKFLOW OBSERVED / SEE CURRENT ADDENDUM | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/yanyuwrite-template-handoff.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/CURIS_WRITING_REFERENCE_CAPABILITY_ADOPTION_AUDIT.md` | REVIEW | Review | TARGETED PRODUCT CONTRACT COMPLETION CANDIDATE | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/CURIS_YANYUWRITE_MEMBER_WORKFLOW_DEEP_DIVE.md` | RESEARCH | Review | END-TO-END SAMPLE OBSERVED / TARGETED GAPS REMAIN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/member-workflow/SESSION_JOURNAL.md` | EVIDENCE | Draft | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/member-workflow/02-background-review.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/member-workflow/10-batch-style-rewrite-contract.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/member-workflow/10-batch-contract.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/member-workflow/10-batch-polish-contract.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/member-workflow/10-polish-contract.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/reference-capability-reconciliation/member-workflow/07-framework-preview.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/writing-business-product-structure-2026-09-21/creative-core-reaudit/WRITING_CREATIVE_CORE_REACCEPTANCE_REVIEW.md` | REVIEW | Review | TARGETED REVISION REQUIRED；不接受“六条必须落实全部闭合”的结论。 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/g1-g6-contract-closure-2026-09-15/CURIS_G1_G6_CAPABILITY_CONTRACT_CLOSURE.md` | RESEARCH | Review | PROPOSED CONTRACT CLOSURE — CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/g1-g6-contract-closure-2026-09-15/README.md` | RESEARCH | Review | SUBMITTED FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/g1-g6-contract-closure-2026-09-15/RESEARCH_JOURNAL.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/g1-g6-contract-closure-2026-09-15/REQUIRED_CAPABILITIES_AND_SEARCH_LOG.md` | RESEARCH | Draft | DEFINE FIRST — BEFORE EXTERNAL SEARCH | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_UI_PROBLEM_REGISTER.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_MISSING_CAPABILITY_REGISTER.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_PIXEL_LEVEL_COMPETITIVE_REFERENCE_MATRIX.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_SYSTEM_COMPETITIVE_RESEARCH_MASTER_PLAN.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_RESEARCH_WORKBUDDY_LOCAL_EVIDENCE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_COMPETITIVE_CROSS_PRODUCT_MATRICES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_RESEARCH_CHATGPT_FUNCTION_INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_RESEARCH_MANUS_FUNCTION_INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_COMPETITIVE_SETTINGS_MATRIX.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_RESEARCH_COZE_FUNCTION_INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_CURRENT_UI_AUDIT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_PAGE_REFERENCE_BLUEPRINT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_SYSTEM_COMPETITIVE_RESEARCH_SYNTHESIS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_RESEARCH_ZCODE_FUNCTION_INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_COMPETITIVE_PATTERN_LIBRARY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_DESKTOP_PRODUCT_AND_DESIGN_DIRECTION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_RESEARCH_DEVIN_FUNCTION_INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/system_competitive_research/CURIS_PRODUCT_CAPABILITY_GAP_MATRIX.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/music-business-product-structure-2026-09-22/CURIS_MUSIC_HTML_EXPLORATION_CLOSURE.md` | REVIEW / EVIDENCE | Review | CEO ACCEPTED PRODUCT CANDIDATE + HTML EXPLORATION DIRECTION / HTML EXPLORATION CLOSED；非Frozen Author | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/music-business-product-structure-2026-09-22/CURIS_MUSIC_BUSINESS_PRODUCT_STRUCTURE_CANDIDATE.md` | RESEARCH | Review | CEO ACCEPTED PRODUCT CANDIDATE / HTML EXPLORATION ACCEPTED；非Frozen、非Runtime验收 | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/music-business-product-structure-2026-09-22/CURIS_MUSIC_BUSINESS_RELATIONSHIP_MAP.md` | RESEARCH | Review | CEO ACCEPTED RELATIONSHIP CANDIDATE / HTML EXPLORATION ACCEPTED；非Frozen、非Runtime图 | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/music-business-product-structure-2026-09-22/CURIS_MUSIC_BUSINESS_GAP_AUDIT.md` | REVIEW | Review | CEO ACCEPTED PRODUCT CANDIDATE + HTML EXPRESSION；EXECUTION GAPS OPEN / NOT FROZEN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/professional-workspace-product-language-2026-09-21/CURIS_PRODUCT_LANGUAGE_RECONCILIATION_INDEX.md` | RESEARCH | Review | COMPLETE — READY FOR CEO REVIEW（仅产品语言候选整理） | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/professional-workspace-product-language-2026-09-21/CURIS_PROFESSIONAL_WORKSPACE_PRODUCT_GRAMMAR_COMPARISON.md` | RESEARCH | Review | CROSS-BUSINESS CANDIDATE — CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/professional-workspace-product-language-2026-09-21/CURIS_VISUAL_LANGUAGE_DELTA_FROM_CURRENT.md` | RESEARCH | Review | CANDIDATE DELTA — NO AUTHORITY WRITE | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/professional-workspace-product-language-2026-09-21/CURIS_PROFESSIONAL_WORKSPACE_VISUAL_LANGUAGE_BASELINE_CANDIDATE.md` | RESEARCH | Review | VISUAL LANGUAGE CANDIDATE — READY FOR CEO REVIEW | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/professional-workspace-product-language-2026-09-21/MUSIC/CURIS_MUSIC_PRODUCT_LANGUAGE_CANDIDATE.md` | RESEARCH | Review | PRODUCT LANGUAGE CANDIDATE — CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/professional-workspace-product-language-2026-09-21/RD/CURIS_RD_PRODUCT_LANGUAGE_CANDIDATE.md` | RESEARCH | Review | PRODUCT LANGUAGE CANDIDATE — CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/professional-workspace-product-language-2026-09-21/WRITING/CURIS_WRITING_PRODUCT_LANGUAGE_CANDIDATE.md` | RESEARCH | Review | PRODUCT LANGUAGE CANDIDATE — CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/codex-phase-2-verification/CURIS_CODEX_COMPETITIVE_VERIFICATION_REVIEW.md` | RESEARCH / EVIDENCE | Review | FOR CEO / CHATGPT REVIEW — recommendations only; NO IMPLEMENTATION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/codex-phase-2-verification/CURIS_HTML_PIXEL_FIDELITY_AUDIT.md` | RESEARCH / EVIDENCE | Review | FOR CEO / CHATGPT REVIEW — recommendations only; NO IMPLEMENTATIO<!DOCTYPE html> | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/codex-phase-2-verification/CURIS_COMPETITIVE_REFERENCE_VERIFICATION.md` | RESEARCH / EVIDENCE | Review | FOR CEO / CHATGPT REVIEW — no Product Authority write | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/codex-phase-2-verification/CURIS_FINAL_COMPETITIVE_REFERENCE_DECISIONS.md` | RESEARCH / EVIDENCE | Review | FOR CEO / CHATGPT REVIEW — no Product Authority write | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/codex-phase-2-verification/CURIS_HTML_CURRENT_TRUTH_DRIFT_AUDIT.md` | RESEARCH / EVIDENCE | Review | FOR CEO / CHATGPT REVIEW — recommendations only; NO IMPLEMENTATION | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/codex-phase-2-verification/evidence/reference-decisions.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/codex-phase-2-verification/evidence/EVIDENCE_INDEX.md` | RESEARCH / EVIDENCE | Review | FOR CEO / CHATGPT REVIEW — recommendations only; NO IMPLEMENTATION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/business-working-space-baseline-2026-09-20/CURIS_BUSINESS_WORKING_SPACE_BASELINE_CANDIDATE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/content-growth-product-language-2026-09-14/CURIS_CONTENT_GROWTH_PRODUCT_LANGUAGE_V2.md` | RESEARCH / PRODUCT LANGUAGE REVIEW | Review | V2 CANDIDATE — READY FOR CEO REVIEW；NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/shared-employee-interaction-2026-09-23/CURIS_V1_SHARED_EMPLOYEE_INTERACTION_MAP.md` | RESEARCH / DECISION EVIDENCE | Review | ACCEPTED / RECONCILED — NOT A SECOND AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/shared-employee-interaction-2026-09-23/CURIS_V1_SHARED_EMPLOYEE_INTERACTION_CANDIDATE.md` | RESEARCH / DECISION EVIDENCE | Review | ACCEPTED / RECONCILED — NOT A SECOND AUTHORITY / NOT RUNTIME ACCEPTANCE | YES | UNKNOWN | YES |
| `docs/research/aitoearn-execution-provider-2026-09-14/CURIS_AITO_EARN_SOCIAL_PLATFORM_EXECUTION_PROVIDER_REVIEW.md` | REVIEW | Review | C — PARTIAL PLATFORM PROVIDER CANDIDATE；D — NOT ACCEPTED AS PRIMARY DEPENDENCY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_HTML_FLOW_SIMPLIFICATION_AND_CONTRACT_REVIEW.md` | REVIEW | Review | FIX REQUIRED / PRODUCT CONTRACT PATCH PROPOSED / NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_TEAM_WORKSPACE_PRODUCT_STRUCTURE_CANDIDATE.md` | RESEARCH / PRODUCT STRUCTURE CANDIDATE | Review | PRODUCT STRUCTURE CANDIDATE READY FOR CEO REVIEW — NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_R5_INDEPENDENT_REVIEW.md` | REVIEW | Review | IMPROVED / FIX REQUIRED / NOT ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_STANDALONE_WORKSPACE_ARCHITECTURE.md` | RESEARCH / PRODUCT CONTRACT CANDIDATE | Review | REFERENCE-INFORMED CANDIDATE — NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_HTML_REVISION_INSTRUCTION.md` | RESEARCH / HANDOFF INSTRUCTION | Review | READY TO HAND OFF / PROTOTYPE ONLY / NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_PROFESSIONAL_WORKSPACE_REFERENCE_STUDY.md` | RESEARCH / REFERENCE-INFORMED PRODUCT CANDIDATE | Review | COMPLETE WITH TARGETED GAPS — NOT CURRENT AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_OPERATIONAL_PRODUCT_EXPRESSION_CANDIDATE.md` | RESEARCH / PRODUCT CONTRACT CANDIDATE | Review | NOT CURRENT AUTHORITY / STOP FOR CEO REVIEW | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_EMPLOYEE_COLLABORATION_AND_PRODUCTION_RECONCILIATION.md` | RESEARCH / PRODUCT CONTRACT CANDIDATE | Review | PRODUCT EXPRESSION RECONCILED — READY FOR TARGETED HTML REVISION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_HTML_TARGETED_REVISION_REVIEW.md` | REVIEW | Review | TARGETED REVISION IMPROVED — NOT ACCEPTED; FIX REQUIRED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_HTML_PRODUCT_EXPRESSION_REVIEW.md` | REVIEW | Review | CEO REVIEW REQUIRED — NO CHANGES AUTHORIZED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/newmedia-workspace-reference-2026-09-16/CURIS_CONTENT_GROWTH_REFERENCE_MATRIX.md` | RESEARCH / COMPARISON | Review | NOT CURRENT AUTHORITY — STOP FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-product-expression-2026-09-14/CURIS_FULL_PRODUCT_EXPRESSION_V1.md` | REVIEW / UI-READY PRODUCT SPECIFICATION CANDIDATE | Review | COMPLETE SPECIFICATION CANDIDATE — CEO REVIEW REQUIRED；NOT CURRENT AUTHORITY | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/full-product-rethink-2026-09-14/CURIS_2026_09_14_FULL_PRODUCT_RETHINK_REVIEW.md` | REVIEW | Review | PARTIAL KEEP / CORRECTIONS REQUIRED / BASELINE CANDIDATES ONLY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/surface-contracts.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/CURIS_FULL_PRODUCT_EXPRESSION_V2.md` | RESEARCH | Review | PRODUCT EXPRESSION CANDIDATE — CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/V1_COMPARISON.md` | RESEARCH | Review | COMPARISON AFTER CAPABILITY DERIVATION | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/MODEL_PROVIDER_FIELD_CONTRACT.md` | RESEARCH | Review | CANDIDATE — NOT CURRENT IMPLEMENTATION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/README.md` | RESEARCH | Review | SUBMITTED FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/CURIS_BUSINESS_CAPABILITY_CATALOG_ACTIVATION_DERIVATION.md` | RESEARCH | Review | PRODUCT CONTRACT CANDIDATE — REVIEW DEFERRED BY CEO; MIGRATION EXTENSION ADDED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/RESEARCH_JOURNAL.md` | RESEARCH / EVIDENCE | Review | RESEARCH DELIVERED / CEO REVIEW REQUIRED; V1 READY FOR UI SUSPENDED BY CEO | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/CURIS_FULL_PRODUCT_EXPERIENCE_MAP.md` | RESEARCH | Review | CANDIDATE MAP — NOT AUTHORITY / NOT UI DESIGN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/CURIS_FULL_APP_CAPABILITY_COMPLETENESS_DERIVATION.md` | RESEARCH | Review | DERIVATION COMPLETE / CANDIDATE — CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/FIRST_PASS_AND_ADVERSARIAL_REVIEW.md` | RESEARCH | Review | TWO PASSES COMPLETED — SUPPORTING RESEARCH | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/SETTINGS_FIELD_REGISTER.md` | RESEARCH | Review | CANDIDATE — NOT CURRENT CONFIGURATION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/COMPLETION_AUDIT.md` | EVIDENCE / REVIEW | Review | RESEARCH DELIVERABLES VERIFIED — PRODUCT READINESS C | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/full-app-completeness-2026-09-14/evidence/verify_deliverables.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/CURIS_FINAL_HIFI_HTML_ACCEPTANCE_REVIEW.md` | REVIEW / EVIDENCE | Review | **C — REJECTED / REWORK REQUIRED** | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/RESEARCH_JOURNAL.md` | EVIDENCE / REVIEW | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/evidence/current-dark-rd.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/evidence/source-at-review.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/evidence/current-light-rd.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/evidence/review-input-final-sha256.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/evidence/EVIDENCE_INDEX.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/research/final-hifi-acceptance/evidence/closure-integrity.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/04_Development/RD_IMPLEMENTATION_PLAN_v1.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/04_Development/Curis_Development_Guide.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/04_Development/CURIS_MASTER_DEVELOPMENT_STATE_2026-09-03.md` | EVIDENCE / CURRENT (Implementation Truth snapshot) | Draft | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/04_Development/XHS_IMPLEMENTATION_PLAN_v1.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/04_Development/AGENT_COMPUTER_ACCESS_RUNTIME_DELTA_PLAN.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/04_Development/XHS_RUNTIME_ARCHITECTURE_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/04_Development/RD_PHASE_2B_PRE_IMPLEMENTATION_AUDIT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/design/ceo-dashboard-product-definition.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/design/phase1c-ceo-office-ui-v3.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/design/phase1c-ceo-office-ui-redesign.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/Content_Growth_Research/Curis_Content_Growth_Research_Review.md` | UNKNOWN | RESEARCH / EXPERT RECOMMENDATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Research/Curis_Content_Growth_Operating_Strategy_Product_Handoff.md` | UNKNOWN | RESEARCH / EXPERT RECOMMENDATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CEO_OPERATING_CORE_RECOVERY_AUDIT_2026-08-18.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/CURIS_CONTENT_GROWTH_PRODUCT_LANGUAGE_DERIVATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Blueprint.html` | UNKNOWN | UNKNOWN | UNKNOWN | YES | UNKNOWN | YES |
| `docs/01_Product/Blueprint_vs_UI_Diff_2026-08-06.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Talent_Market_Product_Map.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_FULL_PRODUCT_STRUCTURE_AND_INTERACTION_INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_BUSINESS_TO_PRODUCT_TRANSLATION_LEDGER.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Talent_Candidate_Package_2026-08-18.md` | UNKNOWN | Candidate（非 CURIS_READY） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Development_Queue_Pack.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Agent_Computer_Access_Contract_Candidate.md` | UNKNOWN | Deprecated | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/Product_Blueprint_Upgrade_Audit.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_UI_Blueprint_Prototype.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_PRODUCT_DERIVATION_ROUND1_CORRECTION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/AI_Capability_Integration_Report.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/UI_Blueprint_Upgrade_Audit.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_UI_Evidence_Alignment_2026-08-09.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_PRODUCT_DERIVATION_METHOD_V2_VALIDATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Derivation_Journal.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_PRODUCT_DERIVATION_GAP_REGISTER.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/Curis_Talent_Market_Integration_Contract.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_DOUYIN_REAL_PLATFORM_OPERATING_DEEP_DIVE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/AI_Capability_UI_Contract.md` | UNKNOWN | Review | UNKNOWN | YES | UNKNOWN | YES |
| `docs/01_Product/Agent_Adapter_Contract.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Context.md` | CURRENT / PRODUCT MODULE CONTEXT · Status: Frozen. | Frozen | UNKNOWN | YES | UNKNOWN | YES |
| `docs/01_Product/Curis_Product_Visual_Master_Map_v1.0.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Reasoning_Record.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Master_Map.md` | CURRENT / PRODUCT STRUCTURE AUTHORITY. Status: Frozen. Disposition: RECORDED / CURRENT — INCLUDED IN | Frozen · Authority Class: CURRENT / PRODUCT EXPANSION · Disposition: CEO ACCEPTE | CURIS PRODUCT TRUTH — FINAL ACCEPTED / FROZEN | YES | explicit supersede wording found | YES |
| `docs/01_Product/Curis_Product_Page_Map_v1.0.md` | UNKNOWN | REVIEW REQUIRED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_CONTENT_GROWTH_BUSINESS_TO_PRODUCT_TRANSLATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_UI_Flow_Pack.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Business_Runtime_Gap_Report_2026-07-31.md` | UNKNOWN | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/CURIS_PRODUCT_DERIVATION_REBUILD.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/Curis_Capability_Intelligence_SOP.md` | UNKNOWN | Frozen（运营规程，CEO 2026-08-18 通过） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Business_Runtime_Definition_v0.1.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Assembly_Pack.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_PRODUCT_CAPABILITY_DERIVATION_LEDGER.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_CONTENT_GROWTH_AI_USER_OPERATING_BOUNDARY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/THREE-DOCUMENT_CONSISTENCY_AUDIT_2026-08-18.md` | REVIEW | Frozen | FINAL AUTHORITY CLEANUP COMPLETE — CANONICAL BUSINESS SPINE ACCEPTED — OPERATING LIFECYCLE APPROVED  | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/AI_Capability_Current_State_Audit.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_PRODUCT_STRUCTURE_BASELINE_PRE_DESIGN_RESEARCH.md` | UNKNOWN | UNKNOWN | UNKNOWN | YES | UNKNOWN | YES |
| `docs/01_Product/CURIS_CONTENT_GROWTH_FULL_PRODUCT_CAPABILITY_DERIVATION.md` | RESEARCH→候选能力登记（Draft，待 CEO 判定 Monetization Operating Model 后转正） | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_PRODUCT_DEFINITION_REBUILD.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_Rethink_Reasoning_2026-08-13.md` | UNKNOWN | REVIEW REQUIRED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis_Product_UI_Blueprint.html` | UNKNOWN | UNKNOWN | UNKNOWN | YES | UNKNOWN | YES |
| `docs/01_Product/Curis_Talent_Chinese_Productization_Batch1.md` | UNKNOWN | Product-facing Presentation（非 Source Truth） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/CURIS_CONTENT_GROWTH_BUSINESS_LOGIC_V2.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/65 Curis MVP完整产品骨架实施规范（MVP Product Foundation Specification）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/66 Curis版本路线图与长期演进规划（Product Roadmap）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/39 商业化产品架构规范（Commercial Product Architecture）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/67 Curis MVP开发范围冻结清单（MVP Scope Freeze）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/45 产品扩展优先级与未来能力边界规范（Product Expansion Boundary）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/20 Agent运行与调度系统（Agent Runtime & Orchestration）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/44 Business Template市场与业务生态规范（Business Template Marketplace）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Development Specification v1.0/28 Curis本地运行架构规范（Desktop Runtime Architecture）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Official Docs v1.0/02 Product Model（产品模型与核心对象）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Curis Official Docs v1.0/01 Product Vision（产品定位与愿景）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/43 产品验收规范（Product Acceptance）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/48 Business Template 示例库规范（Business Template Library）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/44 产品设计检查清单（Product Design Checklist）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/18 业务模板系统（Business Template System）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/50 Curis 产品最终结构总结（Final Product Structure）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/38 API产品架构规范（API Product Architecture Specification）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/15 经营分析（Business Analysis）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/01_Product/Curis 产品梳理 1.0_副本/Product Bible v1.0/35 产品路线图（Product Roadmap）.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/08_Change_Log/CHANGE_LOG.md` | CURRENT / IMPLEMENTATION EVIDENCE | Frozen · Authority Class: CHANGE HISTORY · Disposition: CEO ACCEPTED / V1 PRODUC | IMPLEMENTED / ACCEPTED CANDIDATE | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0042-calm-executive-visual-language.md` | UNKNOWN | Frozen | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0046-local-agent-computer-access-authority.md` | UNKNOWN | Frozen | UNKNOWN | YES | explicit supersede wording found | YES |
| `docs/07_Decisions/ADR-0040-company-os-workspace-product-reset.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0037-domain-frozen-entry-documents.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0036-workspace-admin-boundary.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0041-business-runtime-completion-standard.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0045-ordinary-user-desktop-product-rebaseline.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0044-first-arrival-and-company-space.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0039-phase3b1-workspace-blueprint-migration.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0034-main-baseline-restoration.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0038-status-only-historical-governance.md` | UNKNOWN | Frozen | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0035-desktop-first.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0033-global-assistant-runtime.md` | UNKNOWN | Frozen | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/07_Decisions/ADR-0043-theme-modes-and-neutral-palette.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/curis-takeover/07-Product-Derivation-Plain-Language.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/plan/admin-asset-factory-product-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/plan/v2-p0p1-architect-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/plan/agent-conversion-pilot-b-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/plan/blueprint-4.4-review-readiness.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/plan/curis-product-completion-roadmap-evoflow-2026-08-10.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/plan/ai-company-asset-factory-v2-roadmap-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_IA_ROUND2_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_USER_JOURNEY_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CURIS_SHARED_VISUAL_FRAMEWORK_AND_CONTENT_GROWTH_FIGMA_CONTRACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_AI_EMPLOYEE_DECISION_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_CEO_EXPERIENCE_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_CONTENT_EMPLOYEE_INTERACTION_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_FUNCTIONAL_INTERACTION_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_CONFIGURATION_OWNERSHIP_AUDIT.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_PRODUCT_EXPERIENCE_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_PRODUCT_MAPPING_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_CURRENT_UI_RECONCILIATION.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，未修改任何页面） | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_SHARED_VS_CHANNEL_MATRIX.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen） | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_PRE_IA_CONTRACT_CLOSURE.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_DOMAIN_OPERATING_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION** （非 Frozen，非 Authority 修改） | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_CHANNEL_ACCOUNT_PUBLISHING_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_IA_ROUND2_OBJECT_MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_SOURCE_TOPIC_RESEARCH_INTERACTION.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_UNIT_ECONOMICS_AND_DEPTH_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_ONBOARDING_AND_DAILY_OPERATING_MODEL.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_CEO_DAILY_SIMULATION.md` | UNKNOWN | **RESEARCH / EXPERT RECOMMENDATION**（非 Frozen，非 Authority 修改） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Content_Growth_Professional_Workspace_Research/CONTENT_GROWTH_IA_ROUND1_RED_TEAM_TAKEOVER_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/00_Context/PRODUCT_DOCUMENT_POINTER.md` | FROZEN / TRUTH ROUTER | Frozen | RECORDED / CURRENT — INCLUDED IN CONTROLLED BASELINE PROMOTION | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/00_Context/CURRENT_STATE.md` | CURRENT / IMPLEMENTATION TRUTH ROUTER | Frozen · Authority Class: CURRENT / PRODUCT FREEZE / IMPLEMENTATION BOUNDARY。 | A–C BASELINE PROMOTED; D GOVERNANCE ROUTE REGISTERED | YES | explicit supersede wording found | YES |
| `docs/00_Context/DOCUMENT_INVENTORY.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/00_Context/CURIS_FACT_BASELINE_2026-08-09.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/00_Context/PRODUCT_DOCUMENT_MIGRATION_RULES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/00_Context/DOCUMENT_STATUS_RULES.md` | UNKNOWN | Frozen | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/sprints/sprint-3-role-context-runtime-reference.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/sprints/sprint-0-organization-review.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/sprints/ai-task-executor-mvp-release-candidate.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/company-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/workflow-runtime-contract.md` | UNKNOWN | Phase-5.5 contract prepared for Phase-6 Workflow MVP. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/capability-type-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/capability-package-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/admin-capability-package-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/workflow-trigger-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/pricing-contract.md` | UNKNOWN | Frozen v1 commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/ceo-dashboard-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/official-skill-catalog-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/contracts/department-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/company-package-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/billing-rule-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/workflow-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/company-package-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/project-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/quota-rule-contract.md` | UNKNOWN | **Phase-9A P1 · QuotaRule Configuration（实体契约）** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/value-event-type-contract.md` | UNKNOWN | Phase-7.5 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/dashboard-template-admin-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/capability-package-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/pricing-package-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/skill-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/employee-template-instance-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/value-event-contract.md` | UNKNOWN | Validated for Phase-7.5 Commercial Validation | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/template-instance-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/contracts/commercial-configuration-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/billing-domain-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/pricing-rule-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/department-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/employee-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/company-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/tool-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/employee-seat-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/project-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/employee-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/admin-plan-management-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/template-catalog-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/employee-seat-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/admin-quota-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/contracts/company-operation-flow-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase3-demo-freeze-report.md` | UNKNOWN | demo freeze ready. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase65-post-workflow-roadmap-review.md` | UNKNOWN | roadmap review and next-gate preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase4-ai-employee-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase55-post-g2-roadmap-review.md` | UNKNOWN | roadmap review and contract preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase1-company-runtime-foundation-report.md` | UNKNOWN | verified implementation complete | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase3-workspace-self-extension-rc.md` | UNKNOWN | RC verification passed with one fix applied in Workspace frontend request header | - Not a Curis product code defect. | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase6-workflow-mvp-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase45-workspace-demo-review-roadmap.md` | UNKNOWN | review and roadmap recommendation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase5-g2-credential-vault-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase9a-commercial-design-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase1b-template-runtime-integration-gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/release/phase1a-company-project-runtime-backend.md` | UNKNOWN | implementation report | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/product/CURIS_PRODUCT_BASELINE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/product/curis-product-vision-current-stage.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/product/adr0028_phase1_shared_contract_handoff.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/product/Foundation/Asset_Governance_Foundation.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/decisions/ADR-0019-d1-runtime-role-wiring-boundaries.md` | UNKNOWN | Proposed — for 质量运行席 verification, then 产品规划席 acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/decisions/ADR-0018-sprint3-role-context-runtime-unblock.md` | UNKNOWN | Accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/decisions/commercial-package-model-v1.md` | UNKNOWN | Frozen for first commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/decisions/ADR-0006-role-context-runtime-reference-boundaries.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/decisions/commercial-roadmap.md` | UNKNOWN | Frozen v1 commercial package roadmap | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/decisions/ADR-0012-evolution-decision-evidence-reliability-boundaries.md` | UNKNOWN | Proposed for quality verification | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/decisions/ADR-0029-model-gateway-production-security-boundary.md` | UNKNOWN | Accepted by Security Boundary Seat | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/decisions/ADR-0009-ai-task-executor-mvp-release-candidate-boundaries.md` | UNKNOWN | Accepted by 产品规划席 on 2026-07-06 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/pmo/source-control-baseline-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/pmo/20260719_quota_handoff_plan.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/pmo/archive/PROJECT_STATUS_HISTORY_2026-07-12.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/architecture/b-layer-runtime-governance-decisionsink.md` | UNKNOWN | str                # "pending" | "resolved" | "cancelled" | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/architecture/b-layer-runtime-governance-impl-plan.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/architecture/curis-assistant-runtime-architecture-report.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/architecture/curis-assistant-architecture-review.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/architecture/b-layer-runtime-governance.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/architecture/issue-b-ceo-runtime-evidence-impl-plan.md` | UNKNOWN | str = ""                       # active/disabled/... | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_AUTHORITY_GRAPH.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_PRODUCT_TOPIC_REGISTRY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/build_audit.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_RUNTIME_REALITY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_BACKLOG_REGISTRY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/AUDIT_SUMMARY.md` | UNKNOWN | **READY FOR CEO REVIEW — inventory complete; product truth reconciliation is par | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_PRODUCT_TRUTH_CONFLICT_REGISTER.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_CURRENT_ENTRYPOINT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_WORKSPACE_CLEANUP_PLAN.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_PRODUCT_FACT_SOURCE_REGISTRY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_V1_PRODUCT_TRUTH_MATRIX.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_DECISION_HISTORY_REGISTRY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/audit/CURIS_FULL_WORKSPACE_TRUTH_AUDIT_2026-09-24/CURIS_EXPLORATION_REGISTRY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_HTML_CURRENT_TRUTH_DRIFT_RECHECK.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_HIFI_HTML_BASELINE_CONFIRMATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_HIFI_VISUAL_QUALITY_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/HIFI_VISUAL_REVIEW_GALLERY.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_FULL_PRODUCT_HTML_PROTOTYPE_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/README.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/PROFESSIONAL_BUSINESS_EXISTING_TRUTH.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_HIFI_VISUAL_NOISE_AUDIT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_HTML_PIXEL_FIDELITY_RECHECK.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_HTML_INTERACTION_RECHECK.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/CURIS_HTML_RECONCILIATION_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/prototypes/full-product-html/js/views-business.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/team/quality-runtime-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/team/product-planning-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/team/gate-decision-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/team/conversations/CONV-SEAT-PRODUCT-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/XHS_Professional_Workspace_Research/CURIS_XHS_PROFESSIONAL_WORKSPACE_DOMAIN_RESEARCH.md` | UNKNOWN | RESEARCH / EXPERT RECOMMENDATION | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/XHS_Professional_Workspace_Research/XHS_PROTOTYPE_GAP_MATRIX.md` | UNKNOWN | RESEARCH / EXPERT RECOMMENDATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/review/2026-07-18_curis-joint-progress-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/review/2026-07-17_admin-asset-real-status-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/review/2026-07-17_workspace-real-status-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/review/phase9a-employee-seat-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/review/phase9a-capability-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/05_Workspace_Engineering/Curis_Workspace_Engineering_Lifecycle.md` | CURRENT / FROZEN PRODUCT SEMANTICS（仅本小节）；其余方法论仍Candidate。消费[Company OS Shared §19](../03_Design/Curi | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/05_Workspace_Engineering/CURIS_WORKSPACE_ENGINEERING_PRODUCT_HANDOFF.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/05_Workspace_Engineering/Curis_RD_Methodology_Gap_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/05_Workspace_Engineering/Curis_Workspace_Engineering_Methodology.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/05_Workspace_Engineering/Curis_Workspace_Engineering_Expert_Handoff_Protocol.md` | UNKNOWN | RESEARCH / EXPERT RECOMMENDATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/02_Architecture/WORKSPACE_ENGINEERING_P05_COMPANY_INTEGRATION_AUDIT.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/02_Architecture/WORKSPACE_PACKAGE_COMPANY_OS_IDENTITY_REFERENCE_CONTRACT.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/02_Architecture/CURIS_MULTI_SURFACE_WORKSPACE_PACKAGE_CONTRACT_CANDIDATE.md` | REVIEW · ARCHITECTURE CONTRACT CANDIDATE | Review | CEO ACCEPTED / IMPLEMENTED CONTRACT BASELINE | NO | UNKNOWN | NO / UNKNOWN |
| `docs/02_Architecture/WORKSPACE_ENGINEERING_RUNTIME_AND_EXTENSIBILITY_AUDIT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/02_Architecture/WORKSPACE_ENGINEERING_END_TO_END_ACCEPTANCE_CONTRACT.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/02_Architecture/WORKSPACE_PACKAGE_TECHNICAL_PROPOSAL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/02_Architecture/Curis_System_Architecture.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Target_Account_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Core_Interaction_Spec.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_UI_Review_2026-08-04.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/WORKBUDDY_PROJECT_TO_CURIS_WORKSPACE_LONG_TERM_IA_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Strategy_Evolution_Interaction.md` | UNKNOWN | OPERATING STRATEGY UX TRANSLATION · APPROVED CANDIDATE（非 Frozen · 非高保真） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_RD_Workspace_UI_Drift_Audit_v1.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Workspace_Engineering_Visual_Design_Closure.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Lightweight_Queue_Bottleneck_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/CONTENT_GROWTH_SHARED_CONTRACT_PLAN.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_BATCH_B_CONTRACT_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_XHS_Workspace_State_Semantics_Audit.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Shared_Employee_Service_Relation_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_RD_Design_Phase_Closeout_2026-08-15.md` | UNKNOWN | UNKNOWN | UNKNOWN | YES | UNKNOWN | YES |
| `docs/03_Design/CURIS_SHARED_EMPLOYEE_WORKSTATION_PATTERN_CLOSURE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/CURIS_VISUAL_STANDARD_V1.md` | FROZEN / DESIGN | Frozen | CEO SELECTED D — CURRENT VISUAL LANGUAGE | YES | explicit supersede wording found | YES |
| `docs/03_Design/WORKSPACE_ENGINEERING_PANE_RESPONSIBILITY_CLOSURE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_XHS_Workspace_Instance_Spec_v1.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Information_Architecture_Exploration.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Workspace_Engineering_Product_Translation_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/BATCH_A_CONTRACT_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Responsibility_Requirement_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_XHS_Workspace_UI_Authority_Map.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Variant_Publication_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Workspace_Engineering_Technical_Reality_Delta_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/CURIS_TRAE_VISUAL_DESIGN_RULES.md` | FROZEN / DESIGN INPUT | Frozen | Minimal qualification input derived from `CURIS_VISUAL_STANDARD_V1.md` | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Production_Channel_Operations_Model.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/CURIS_COMPANY_MAP_ORGANIZATION_GRAPH_RESEARCH.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Douyin_End_to_End_Automation_Feasibility.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_UI_Frontend_Handoff_Memo_2026-08-05.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/CURIS_SHARED_BUSINESS_WORKSPACE_MAIN_COMPOSITION_CLOSURE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/UI_Designer_Handoff_2026-08-04.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Multi_Channel_Architecture_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Core_Interaction_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_XHS_Shell_Shared_Delta_Summary.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Domain_Authority_Consolidation_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Company_OS_Shared_Authority_Consolidation_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Workspace_Shell.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_TTK_Workspace_Product_Model_Proposal.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_TTK_vs_XHS_Reuse_Matrix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/CURIS_SHARED_EMPLOYEE_WORK_AREA_AND_COMPOSER_CONTRACT_CLOSURE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_UX_Model_Exploration.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_CEO_Decision_Pattern_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Employee_Method_Experience.md` | UNKNOWN | OPERATING STRATEGY UX TRANSLATION · DESIGN CANDIDATE（非 Frozen · 非高保真） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Workspace_Engineering_Product_Translation.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Product_Model_Closure.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_XHS_Workspace_Interaction_Exploration_v2.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Workspace_Shell_Contract_And_Shared_Patterns.md` | CURRENT / FROZEN. Disposition: RECORDED / CURRENT — INCLUDED IN CONTROLLED BASELINE PROMOTION. | Frozen · Authority Class: CURRENT / SHELL PRODUCT AUTHORITY. | UNKNOWN | YES | explicit supersede wording found | YES |
| `docs/03_Design/CURIS_COMPANY_MAP_VISUAL_EXPLORATION.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_BATCH_C_CONTRACT_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_XHS_Workspace_Design_Exploration_v1.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Workspace_Engineering_Company_Integration_Product_Delta.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Frontend_Team_Forced_Align_Handoff_v2_2026-08-06.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Channel_Account_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Intent_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Organization_Routing_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Domain_Authority.md` | CURRENT / FROZEN DOMAIN PRODUCT AUTHORITY | **Frozen** | CEO ACCEPTED RECONCILIATION CONSUMED — CONSOLIDATION REVIEW REQUIRED；不是实现验收。§5.4为账号经营与Provider正式合同。 | YES | UNKNOWN | YES |
| `docs/03_Design/UI_Exploration_Gap_Audit_2026-08-04.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Company_OS_Shared_Authority.md` | CURRENT / FROZEN. Disposition: RECORDED / CURRENT — INCLUDED IN CONTROLLED BASELINE PROMOTION. | Frozen · Authority Class: CURRENT / SHARED PRODUCT AUTHORITY · Disposition: CEO  | UNKNOWN | YES | explicit supersede wording found | YES |
| `docs/03_Design/WORKSPACE_ENGINEERING_VISUAL_DESIGN_REMAKE_CLOSURE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Douyin_Automation_Requirements.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Content_Growth_Operating_Strategy_UX_Translation.md` | UNKNOWN | OPERATING STRATEGY UX TRANSLATION · DESIGN CANDIDATE（非 Frozen · 非高保真 · 非前端代码 · 非 | UNKNOWN | YES | UNKNOWN | YES |
| `docs/03_Design/Curis_Desktop_Pane_Shell_Exploration_v1.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_Douyin_Capability_Matrix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Frontend_Team_Structure_Align_Handoff_2026-08-05.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/WORKSPACE_ENGINEERING_FINAL_IA_CLOSURE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/03_Design/Curis_AiToEarn_Architecture_Review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Design_System.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Frontend_Handoff_Instructions_2026-08-05.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/Curis_Operating_Context_Office_Contract_Candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/research/CURIS_VISUAL_DIRECTION_RESEARCH.md` | UNKNOWN | Draft (Research) | 待 CEO 评审 | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/research/CURIS_VISUAL_EXPLORATION_BRIEF.md` | RESEARCH | Review | READY FOR FIGMA MAKE / CEO REVIEW AFTER EXPLORATION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/research/CURIS_FIGMA_MAKE_DESIGN_CONTEXT_PACK.md` | RESEARCH | Review | DESIGN-AI CONTEXT PACK / NOT NEW AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/research/CURIS_VISUAL_SYSTEM_CANDIDATE.md` | RESEARCH | Review | SHARED VISUAL SYSTEM CANDIDATE / CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/research/CURIS_RECOMMENDED_COLOR_RESEARCH.md` | RESEARCH | Review | 视觉参考 / 不构成 Frozen Authority | NO | UNKNOWN | NO / UNKNOWN |
| `docs/03_Design/research/CURIS_VISUAL_DESIGN_SYSTEM_RESEARCH.md` | RESEARCH | Review | CEO REVIEW REQUIRED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/ai-development-organization/task-runtime-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/ai-development-organization/decision-authority-matrix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/ai-development-organization/runtime-state-observer.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/Asset_Convention.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/Curis_Engineering_Convention_Review_Report.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/Folder_Convention.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/Naming_Convention.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/Review_Convention.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/Git_Convention.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/Curis_Engineering_Convention.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/Engineering/AI_Collaboration_Convention.md` | UNKNOWN | Frozen | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/README.md` | UNKNOWN | Frozen | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/99_Archive/design/curis-ui-v2/docs/ui/LOCAL_HANDOFF.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/design/curis-ui-v2/.preflight/preflight.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/curis_blueprint_rejected/Curis_Product_Blueprint_v1.0_REJECTED.html` | UNKNOWN | REJECTED — Generated Outside Curis Project Context | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/handoff/curis-roadmap-r1r2-handoff-2026-07-22.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/handoff/2026_07_23CURIS_PRODUCT_DELIVERY_HANDOFF.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/handoff/team-v2/BOOTSTRAP_HANDOFFS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/handoff/team-v2/HANDOFF_TEMPLATE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/Product/Curis_Product_Master_Map_v2.0_Historical_2026-08-18.md` | HISTORY | ARCHIVED | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/99_Archive/Product/README.md` | HISTORY | Deprecated | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/99_Archive/Product/THREE-DOCUMENT_CONSISTENCY_AUDIT_2026-08-18_Historical_Snapshot.md` | UNKNOWN | READY FOR CEO FINAL PRODUCT TRUTH REVIEW | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/99_Archive/curis_workspace_blueprint/RESEARCH/00-REFERENCE-PRODUCTS.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/curis_workspace_blueprint/00-FOUNDATION/02-PRODUCT-PHILOSOPHY.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/curis_workspace_blueprint/02-PRODUCT/00-PRODUCT-MODULES.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/curis_workspace_blueprint/02-PRODUCT/01-BUSINESS-PACKS.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/99_Archive/curis_workspace_blueprint/01-ARCHITECTURE/01-DOMAIN-MODEL.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PRODUCT_TRUTH_CONSOLIDATION_REVIEW.md` | REVIEW / CONSOLIDATION EXECUTION EVIDENCE | Review | CEO ACCEPTED DECISIONS APPLIED — FINAL CONSISTENCY REVIEW REQUIRED | YES | explicit supersede wording found | YES |
| `docs/reviews/CURIS_V1_MEETING_AUTONOMY_MECHANISM_ADJUDICATION_2026-09-04.md` | REVIEW | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FRONTEND_BATCH_1_IMPLEMENTATION_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_WORKSPACE_SURFACE_OWNERSHIP_MATRIX.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS-V1-M2.5-GENERAL-WORKSPACE-CONTEXT-001_review.md` | REVIEW / EVIDENCE | Review | M2.5A IMPLEMENTED / CLOSED; M2.5B UI-HOLD; CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_XHS_TEAM_SURFACE_OPERATING_MAP.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CORE_PRODUCT_TRUTH_LEDGER.md` | REVIEW / EVIDENCE | Review | READ-ONLY RECONCILIATION / CEO REVIEW REQUIRED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_UI_GAP_MAP.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_WORKFLOW_RUNTIME_IMPLEMENTATION_AUDIT.md` | REVIEW | Review | PENDING CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_WRITING_SHARED_EMPLOYEE_INTERACTION_RECONCILIATION_INSTRUCTIONS.md` | REVIEW / OWNER EXECUTION INSTRUCTION | Review | READY FOR BUSINESS OWNER — NOT COMPLETED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_WORKTREE_REMAINING_RECONCILIATION.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_RUNTIME_CAPABILITY_VALIDATION_BACKLOG.md` | REVIEW / IMPLEMENTATION VALIDATION INPUT | Review | OPEN — POST PRODUCT CONTRACT FREEZE | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FRONTEND_BATCH_1_IMPLEMENTATION_ACCEPTANCE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_WORKTREE_RECONCILIATION_DECISIONS.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FINAL_UI_GAP_REVIEW.md` | REVIEW / EVIDENCE | Review | FINAL UI NOT READY; RELEASE PRESENTATION NOT READY; CEO review required. | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260810_workspace_studio_blueprint_assembly_001_review.md` | UNKNOWN | Completed (Blueprint Draft assembly; Runtime gates open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_MULTI_SURFACE_WORKSPACE_PACKAGE_CONTRACT_RESEARCH.md` | RESEARCH | Review | RESEARCH COMPLETE / CEO REVIEW REQUIRED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CONTENT_GROWTH_PRE_IA_AUTHORITY_RECONCILIATION.md` | REVIEW | Review | STOP FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_GLOBAL_UI_SEVEN_AREA_FINAL_ACCEPTANCE.md` | REVIEW / EVIDENCE | Review | PRODUCT COMPLETE — ACCEPTED WITH RECORDED P2; CEO final review required | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_PRODUCT_COMPLETION_RECONCILIATION.md` | CURRENT / IMPLEMENTATION EVIDENCE | Frozen · Authority Class: CURRENT / PRODUCT COMPLETION GATE · Disposition: CURIS | IMPLEMENTED / ACCEPTED CANDIDATE | YES | explicit supersede wording found | YES |
| `docs/reviews/2026-08-07-code-vs-blueprint-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_DESKTOP_SOURCE_BASELINE_CLOSURE_REVIEW.md` | REVIEW | Review | DESKTOP SOURCE BASELINE READY — CLEAN PACKAGE AND ISOLATED LAUNCH SMOKE VERIFIED — NOT STAGED OR COM | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_GENERAL_WORKSPACE_CONTEXT_SUFFICIENCY_AUDIT.md` | REVIEW / EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_PRODUCT_FREEZE_READINESS.md` | CURRENT / PRODUCT FREEZE DECISION RECORD | Frozen | CEO PRODUCT FREEZE DECISION RECORDED — FROZEN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CONTENT_GROWTH_CHANNEL_CAPABILITY_EVIDENCE_AUDIT.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_SEMANTIC_AMBIGUITY_AUDIT.md` | REVIEW / PRODUCT INPUT SEMANTIC AUDIT | Review | C. PRODUCT SEMANTICS NEED CLARIFICATION | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_PRODUCT_FREEZE.md` | CURRENT / V1 PRODUCT AUTHORITY | Frozen | CURIS V1 PRODUCT CONTRACT — FROZEN / CEO FINAL DECISION RECORDED | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_CREATE_BUSINESS_FLOW_CONTRACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_VISUAL_TOKEN_MIGRATION_MAP.md` | REVIEW / IMPLEMENTATION MIGRATION MAP | Review | IMPLEMENTATION MIGRATION REQUIRED — NO CODE CHANGE AUTHORIZED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_MUSIC_SHARED_EMPLOYEE_INTERACTION_RECONCILIATION_INSTRUCTIONS.md` | REVIEW / OWNER EXECUTION INSTRUCTION | Review | READY FOR BUSINESS OWNER — NOT COMPLETED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CURRENT_VISUAL_SYSTEM_TRUTH.md` | REVIEW | Review | CEO REVIEW REQUIRED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_RESPONSIBILITY_ROUTING_RUNTIME_IMPLEMENTATION_REVIEW.md` | REVIEW | Review | IMPLEMENTED · CONTRACT ALIGNMENT CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260810_desktop_runtime_execution_001_review.md` | UNKNOWN | Completed (runtime bridge; external execution evidence open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_PHASE0_RUNTIME_TRUTH_AUDIT.md` | UNKNOWN | **PARTIAL**. Phase 1 must identify the authoritative existing Business/Workspace | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_CEO_DESK_DESIGN_RECONCILIATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_CORE_PRODUCT_AUTHORITY_RECONCILIATION.md` | REVIEW / EVIDENCE | Review | CORE AUTHORITY DRIFT IDENTIFIED / STOP FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_FIGMA_UPLOAD_MANIFEST.md` | REVIEW / DESIGN INPUT ROUTING | Review | B. READY WITH MINOR NOTES — CONSUMPTION ONLY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_DISTRIBUTION_STRATEGY.md` | FROZEN / PRODUCT STRATEGY RECORD | Frozen | CEO ACCEPTED — TWO-STAGE MACOS DISTRIBUTION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CEO_ASSISTANT_HISTORICAL_PRODUCT_TRUTH_RECOVERY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_UI_FRONTEND_RECONCILIATION_AUDIT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_CROSS_SURFACE_MULTI_WORK_RUNTIME_PROOF_REVIEW.md` | REVIEW | Frozen | PROOF IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_KNOWLEDGE_LIBRARY_IMPLEMENTATION_ACCEPTANCE.md` | CURRENT IMPLEMENTATION TRUTH / ACCEPTANCE REGISTRATION | Frozen | IMPLEMENTED / ACCEPTED | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_FIGMA_VISUAL_EXPLORATION_RETROSPECTIVE.md` | REVIEW | Review | CEO VISUAL DIRECTION SELECTION REQUIRED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_IMPLEMENTATION_READINESS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_CONVERSATION_ATTENTION_LIFECYCLE_REVIEW.md` | REVIEW / IMPLEMENTATION EVIDENCE | Review | IMPLEMENTED / ACCEPTED WITH RECORDED FOLLOW-UP — Conversation core productization acceptance; final  | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_GENERAL_WORKSPACE_P1_FINAL_IMPLEMENTATION_REVIEW.md` | REVIEW | Review | IMPLEMENTED / PARTIAL — PACKAGED NATIVE WORKSPACE INTERACTION UNVERIFIED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_KNOWLEDGE_CANONICAL_SCOPE_TYPED_WORK_REFERENCE_CONTRACT.md` | REVIEW / ARCHITECTURE CANDIDATE | Review | BLOCKER CONTRACT PROPOSED / ACCEPTED CANDIDATE FOR CEO / ARCHITECTURE REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_CONTENT_GROWTH_SHARED_EMPLOYEE_INTERACTION_RECONCILIATION_INSTRUCTIONS.md` | REVIEW / OWNER EXECUTION INSTRUCTION | Review | READY FOR BUSINESS OWNER — NOT COMPLETED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_MEETING_AUTONOMOUS_DISCUSSION_REVIEW.md` | REVIEW | Review | IMPLEMENTED / ACCEPTED CANDIDATE; FINAL MULTI-CYCLE CLOUD ACCEPTANCE PENDING REAL-WORLD EVIDENCE | YES | explicit supersede wording found | YES |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_PRIMARY_TWO_CYCLE_E2E_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_APP_READINESS_AUDIT.md` | REVIEW | Review | V1 NOT READY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260810_workspace_staffing_approval_activation_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_SETTINGS_PRODUCT_CONFIGURATION_RESEARCH.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATION_PRODUCT_SURFACE_MAPPING.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_THREE_LAYER_OPERATING_MODEL_RECONCILIATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CANONICAL_CHILD_WORK_AND_MULTI_WORK_COMMIT_RECONCILIATION.md` | REVIEW | Frozen | IMPLEMENTED / ACCEPTED / COMMITTED / NOT PUSHED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_TALENT_CAPABILITY_PRODUCTIZATION_REVIEW.md` | REVIEW | Review | the previous `Avatar upload/preset persistence` gap is closed by one canonical Employee avatar refer | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_CONTROLLED_BASELINE_PROMOTION_PLAN.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_KNOWLEDGE_LIBRARY_UX_EXPLORATION.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_WORKTREE_CLEANUP_AUDIT.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_PHASE3A_EVALUATION_DECISION_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FINAL_UI_ACCEPTANCE_BACKLOG.md` | CURRENT / UI ACCEPTANCE INPUT | Review | ACTIVE INPUT FOR FINAL UI MASTER — PRODUCT FROZEN; UI WORK NOT STARTED | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_PRODUCT_BLUEPRINT_DEEP_RECONCILIATION.md` | REVIEW / PROPOSED PRODUCT RECONCILIATION | Review | READY WITH CEO DECISIONS — NOT CURRENT PRODUCT AUTHORITY | YES | explicit supersede wording found | YES |
| `docs/reviews/CURIS_PHASE_B_CORE_PRODUCT_RECONCILIATION_REVIEW.md` | REVIEW / IMPLEMENTATION EVIDENCE | Review | IMPLEMENTED / ACCEPTED CANDIDATE — P0 integrated evidence passed | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_WORKSPACE_TEAM_SURFACE_RELATIONSHIP_MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_OPERATING_INTELLIGENCE_PRODUCTIZATION_REVIEW.md` | REVIEW | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_FRONTEND_BASELINE_CLOSURE_REVIEW.md` | REVIEW | Review | FRONTEND DEPENDENCY BASELINE READY — CONTROLLED TARGET TREE VERIFIED — NOT STAGED OR COMMITTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_VISUAL_BASELINE_REAL_PRODUCT_IMPLEMENTATION_REVIEW.md` | REVIEW | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_UI_DEPENDENCY_MATRIX.md` | REVIEW | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_VISUAL_DIRECTION_SELECTION_BOARD.md` | REVIEW | Review | CEO SELECTION REQUIRED — `A`, `B`, `C`, `D`, or `NONE` | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_CORE_PRODUCT_AUTHORITY_REPAIR.md` | CURRENT / ACCEPTED CEO DECISION | Frozen | ROLE DECOMPOSITION ACCEPTED — previous employee-count gate CLOSED | YES | explicit supersede wording found | YES |
| `docs/reviews/CURIS_CANONICAL_BUSINESS_SPINE_AUTHORITY_REVIEW.md` | REVIEW | Frozen | CEO ACCEPTED — IMPLEMENTATION AUTHORIZED / FRONTEND OWNER ASSIGNED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/ORGANIZATION_CENTER_PAGE_CONTRACT_FINAL_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_CROSS_TRACK_SYNTHESIS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_RELEASE_DISTRIBUTION_RECOVERY_REVIEW.md` | REVIEW / EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_STRATEGY_AUTHORITY_RECONCILIATION_REVIEW.md` | REVIEW | Frozen | CEO ACCEPTED / AUTHORITY RECONCILIATION / NO IMPLEMENTATION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_TEAM_OPERATING_UI_RUNTIME_E2E_REVIEW.md` | REVIEW · IMPLEMENTATION EVIDENCE | Review | IMPLEMENTED · CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_GENERAL_WORKSPACE_LIFECYCLE_CLOSURE_REVIEW.md` | REVIEW / IMPLEMENTATION EVIDENCE | Review | **IMPLEMENTED / ACCEPTED** for the bounded General Workspace | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_EMPLOYEE_RECRUITMENT_AVATAR_CLOSURE_REVIEW.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_CLOUD_AI_CONTINUITY_ACCEPTANCE.md` | FROZEN / IMPLEMENTATION ACCEPTANCE RECORD | Frozen | V1-P0-003 IMPLEMENTED / ACCEPTED | YES | explicit supersede wording found | YES |
| `docs/reviews/RECENT_UNREGISTERED_ACCEPTED_TRUTH.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_CLOUD_MODEL_CONTINUITY_IMPLEMENTATION_REVIEW.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_WORKSPACE_RESOLUTION_MODEL_CANDIDATE.md` | RESEARCH / PRODUCT STRATEGY CANDIDATE | Review | READY FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_APP_ENTRY_LIFECYCLE_CONTRACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/2026-08-03-curis-ui-prototype-review.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_COMPLETION_RECONCILIATION.md` | REVIEW — Current Implementation Reconciliation | Review | CEO / ChatGPT V1 Completion Review Required | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_KNOWLEDGE_LIBRARY_PRODUCT_UX_ACCEPTANCE.md` | REVIEW | Review | CEO ACCEPTED / APPROVED UX DIRECTION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260810_product_rederivation_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_GENERAL_WORKSPACE_P1_OPERATING_CLOSURE_REVIEW.md` | REVIEW / EVIDENCE | Review | IMPLEMENTED / PARTIAL | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_WHOLE_APP_PRODUCT_GAP_CLOSURE_REVIEW.md` | EVIDENCE / FORMAL ACCEPTANCE RECORD | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_TEAM_OPERATING_ENGINE_CONTRACT_CANDIDATE.md` | REVIEW | Review | READY FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260810_workspace_operating_cycle_closure_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_APP_ENTRY_FIGMA_BASELINE_AUDIT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_PRODUCT_TRUTH_TARGET_MAP.md` | REVIEW / PROPOSED AUTHORITY MAP | Review | TARGET MAP ONLY — NOT CURRENT PRODUCT AUTHORITY | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_PRODUCT_BLUEPRINT_CHANGE_PLAN.md` | REVIEW / PROPOSED CHANGE PLAN | Review | PLAN ONLY — REQUIRES CEO ACCEPTANCE AND SEPARATE EXECUTION AUTHORIZATION | YES | explicit supersede wording found | YES |
| `docs/reviews/BUSINESS_SPACE_PAGE_CONTRACT_FINAL_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_TEAM_SURFACE_OPERATING_MODEL_RESEARCH.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CANONICAL_BUSINESS_SPINE_IMPLEMENTATION_001_REVIEW.md` | REVIEW | Review | IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_P0_003_KEYCHAIN_IMPLEMENTATION_REVIEW.md` | REVIEW | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_FIGMA_VISUAL_FRAME_MANIFEST.md` | REVIEW | Review | CEO VISUAL DIRECTION SELECTION REQUIRED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CEO_DESK_PAGE_CONTRACT_FINAL_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_BUSINESS_OPERATION_SYNTHESIS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260814_ai_capability_integration_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CONTENT_GROWTH_CEO_AUTHORITY_DECISION_RECONCILIATION.md` | REVIEW | Review | CEO DECISION APPLIED / STOP FOR CEO REVIEW | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_V1_M4_M5_CONTINUOUS_DELIVERY_REVIEW.md` | REVIEW / EVIDENCE | Review — CEO IMPLEMENTATION REVIEW REQUIRED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CANONICAL_USAGE_ATTRIBUTION_IMPLEMENTATION_REVIEW.md` | REVIEW / EVIDENCE | Review | IMPLEMENTED / CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_PHASE1_CONTROL_PERSISTENCE_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_MEETING_ROOM_UI_ACCEPTANCE.md` | CURRENT UI ACCEPTANCE / DESIGN BASELINE | Frozen | UI ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_WHOLE_APP_LIVE_AI_ACCEPTANCE_REGISTRATION.md` | FROZEN / IMPLEMENTATION ACCEPTANCE RECORD | Frozen | WHOLE-APP LIVE AI ACCEPTED WITH RECORDED P1 | YES | explicit supersede wording found | YES |
| `docs/reviews/CURIS_V1_TALENT_CAPABILITY_IMPLEMENTATION_ACCEPTANCE.md` | CURRENT IMPLEMENTATION TRUTH / ACCEPTANCE REGISTRATION | Frozen | IMPLEMENTED / ACCEPTED | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_KNOWLEDGE_FUTURE_COMPATIBILITY_REVIEW.md` | REVIEW | Review | COMPATIBILITY REVIEW COMPLETE — CANDIDATE CONTRACT READY FOR CEO / ARCHITECTURE REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_MEETING_CLOSURE_ENV_PREP_2026-09-04.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260809_desktop_runtime_simulation_001_review.md` | UNKNOWN | Completed (local browser gate; packaged Desktop revalidation open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FRONTEND_BATCH_1_FINAL_ACCEPTANCE.md` | REVIEW | Review | ACCEPTED WITH RECORDED BOUNDARIES | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260809_desktop_runtime_flow_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_AUTHORITY_RECONCILIATION_REVIEW.md` | REVIEW | Frozen | CEO ACCEPTED / AUTHORITY RECONCILED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_OPERATING_LIFECYCLE_CONTRACT_CANDIDATE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/BUSINESS_ACCOUNT_WORKSPACE_PRODUCT_CLARIFICATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_CANONICAL_CHILD_WORK_FOUNDATION_REVIEW.md` | REVIEW | Frozen | IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_FIGMA_DESIGN_INPUT_AUDIT.md` | REVIEW / DESIGN INPUT AUDIT | Review | B. READY WITH MINOR NOTES — FDI-01 CLOSED BY CEO | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_FRONTEND_BASELINE_PROVENANCE_RECONCILIATION.md` | REVIEW | Review | PROVENANCE RECONCILED BY SEMANTIC OWNERSHIP; CONTROLLED TARGET BASELINE RECONSTRUCTED; NOT STAGED OR | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260809_desktop_single_instance_001_review.md` | UNKNOWN | Completed (local behavior; external release gates open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CONTENT_GROWTH_AUTONOMY_GUARDRAIL_CALIBRATION_AUDIT.md` | EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_MULTI_SURFACE_PROFESSIONAL_WORKSPACE_UX_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_PHASE3B_SUCCESSOR_CONTROL_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_CEO_DESK_OPERATING_UI_ACCEPTANCE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_TRAE_VISUAL_SYSTEM_ADDENDUM.md` | FROZEN / DESIGN INPUT | Frozen | DIRECTION D IMPLEMENTATION INPUT | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_MASTER_SHELL_VISUAL_EXECUTION_CONTRACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_FIGMA_DESIGN_INPUT_PACK.md` | REVIEW / DESIGN CONSUMPTION | Review | FIGMA DESIGN CONSUMPTION PACK ONLY — NOT A NEW AUTHORITY | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_KNOWLEDGE_LIBRARY_UI_ACCEPTANCE.md` | CURRENT UI ACCEPTANCE / DESIGN BASELINE | Frozen | UI ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_MULTI_SURFACE_WORKSPACE_PACKAGE_IMPLEMENTATION_REVIEW.md` | REVIEW · IMPLEMENTATION EVIDENCE | Review | IMPLEMENTED / CEO ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FRONTEND_CLEANUP_MAP.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/DEPARTMENT_WORK_SURFACE_PAGE_CONTRACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_QUALITY_MODEL_CANDIDATE.md` | RESEARCH / PRODUCT QUALITY CANDIDATE | Review | READY FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260810_workspace_capability_supply_review_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/BUSINESS_WORK_SURFACE_PAGE_CONTRACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_EVIDENCE_BOUND_LEARNING_REVIEW.md` | REVIEW | Review | IMPLEMENTED / ACCEPTED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_THREE_AREA_DESIGN_ASSET_RECOVERY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_CURRENT_UI_FOUNDATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_TEAM_OPERATING_REAL_EMPLOYEE_E2E_REVIEW.md` | REVIEW | ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_MEETING_ROOM_PRODUCTIZATION_REVIEW.md` | CURRENT / IMPLEMENTATION REGISTRATION. Source: CEO “MEETING ROOM CURRENT STATUS REGISTRATION” decisi | Review | CORE IMPLEMENTED; AUTONOMOUS DISCUSSION IMPLEMENTED / ACCEPTED CANDIDATE; FINAL MULTI-CYCLE CLOUD AC | YES | explicit supersede wording found | YES |
| `docs/reviews/CURIS_UNIVERSAL_PROFESSIONAL_WORKSPACE_MODEL_CANDIDATE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260810_workspace_staffing_proposal_runtime_001_review.md` | UNKNOWN | Completed (proposal materialization; activation gates open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_WHOLE_APP_LIVE_AI_ACCEPTANCE.md` | EVIDENCE | Review | PARTIAL / PRODUCT GAP | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_GENERAL_WORKSPACE_NATIVE_INTERACTION_ACCEPTANCE.md` | EVIDENCE / ACCEPTANCE REVIEW | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_ARCHITECTURE_INTERNAL_RESEARCH.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_PHASE2_SINGLE_CYCLE_EXECUTION_REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_DEVELOPMENT_MASTER_PLAN.md` | REVIEW / PLAN | Review | Proposed shortest path to a usable V1; does not modify Product Authority | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260809_desktop_runtime_workitem_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_MULTI_SURFACE_WORKSPACE_PACKAGE_COMMIT_RECONCILIATION.md` | REVIEW · COMMIT EVIDENCE | Review | CEO ACCEPTED / BOUNDED COMMIT AUTHORIZED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_EMPLOYEE_CONVERSATION_MODEL_EXPERIENCE_CONTRACT.md` | UNKNOWN | UNKNOWN | UNKNOWN | YES | UNKNOWN | YES |
| `docs/reviews/20260810_workspace_staffing_simulation_001_review.md` | UNKNOWN | Completed (isolated staffing simulation; activation gate open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CORE_PRODUCT_DEVIATION_REGISTER.md` | REVIEW / EVIDENCE | Review | CEO REVIEW REQUIRED / NO IMPLEMENTATION | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CANONICAL_EXECUTION_SCOPE_RECONCILIATION_REVIEW.md` | REVIEW / IMPLEMENTATION EVIDENCE | Review | IMPLEMENTED / ACCEPTED CANDIDATE — four-scope infrastructure and Phase B integration verified | YES | explicit supersede wording found | YES |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_CEO_DECISION_PACKET.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PROFESSIONAL_WORKSPACE_STRATEGY_RESEARCH.md` | RESEARCH | Review | RESEARCH COMPLETE / CEO REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_PHASE1_3B_COMMIT_RECONCILIATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_BUSINESS_ACTIVATION_PRODUCT_TRUTH_PATCH_REVIEW.md` | REVIEW / EXECUTION EVIDENCE | Review | CEO ACCEPTED CONTRACT APPLIED — FINAL PATCH REVIEW REQUIRED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FRONTEND_IMPLEMENTATION_READINESS_REVIEW.md` | UNKNOWN | `MISSING`, bounded frontend/local-preference seam. This is not a schema justific | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CODEX_MASTER_DEVELOPMENT_RECOVERY_2026-09-05.md` | REVIEW / EVIDENCE | Review | RECOVERED / IMPLEMENTED PARTIAL — STOP: DEFAULT APP DATABASE MUTATION INCIDENT | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_LONG_RUN_CLOSURE_REPORT.md` | REVIEW | Review | IMPLEMENTED / ACCEPTED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_EXECUTION_BACKLOG.md` | CURRENT / PRODUCT STRUCTURE AUTHORITY | Frozen · Authority Class: CURRENT / V1 PRODUCT SEQUENCE · Disposition: CURIS V1  | RECORDED / CURRENT — INCLUDED IN CONTROLLED BASELINE PROMOTION | YES | explicit supersede wording found | YES |
| `docs/reviews/20260809_desktop_packaging_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_CANONICAL_USAGE_ATTRIBUTION_ARCHITECTURE_REVIEW.md` | REVIEW | Review | PENDING CEO / ARCHITECTURE REVIEW | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_MINIMAL_SHARED_RUNTIME_STAGED_VALIDATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_MEETING_EMPLOYEE_SELF_JUDGMENT_DESIGN_2026-09-04.md` | REVIEW | Draft → Decision Locked (方案1, 2026-09-04) | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_KNOWLEDGE_LIBRARY_PRODUCT_UX_RESEARCH.md` | RESEARCH | Review | STOP FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_APP_ENTRY_UI_ACCEPTANCE.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_FINAL_UI_SURFACE_INVENTORY.md` | REVIEW / EVIDENCE | Review | CURRENT UI INVENTORY FOR CEO REVIEW; not final visual acceptance. | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_UI_INDEPENDENT_DELIVERY_REPORT.md` | REVIEW / EVIDENCE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_KNOWLEDGE_LIBRARY_PRODUCTIZATION_REVIEW.md` | REVIEW | Review | IMPLEMENTED / ACCEPTED CANDIDATE | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_PHASE_B_CORE_PRODUCT_RECONCILIATION_CONTRACT.md` | REVIEW / IMPLEMENTATION CONTRACT CANDIDATE | Review | PHASE B P0 IMPLEMENTATION CONTRACT FINAL CANDIDATE — NOT IMPLEMENTATION AUTHORIZATION | YES | UNKNOWN | YES |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_CORE_IMPLEMENTATION_CLOSURE.md` | REVIEW | Review | CEO ACCEPTED / IMPLEMENTATION BASELINE CLOSED | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_AVATAR_IDENTITY_PATTERN.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/CURIS_V1_ORGANIZATION_CENTER_PRODUCTIZATION_REVIEW.md` | REVIEW | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/CURIS_AUTONOMOUS_OPERATING_V1_CROSS_DOMAIN_CONTRACT_PROOF_REVIEW.md` | REVIEW | Review | IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260813_product_rebaseline/Curis_Product_Master_Map_v1.0.md` | UNKNOWN | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `docs/reviews/align-baseline/frontend-facts-decisions.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/align-baseline/t1-prototype-company-runtime-text.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/align-baseline/frontend-facts-decisions-r3.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/align-baseline/frontend-facts-decisions-r4.json` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/align-baseline/t1-frontend-company-runtime-text.txt` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/ui-runtime-migration-review-2026-08-09/README.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `docs/reviews/20260813_current_state_product_drift_audit/Curis_Current_State_and_Product_Drift_Audit.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-09-20.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-09-21.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-08-20.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-08-24.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.workbuddy/memory/2026-08-21.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.workbuddy/memory/2026-08-16.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-09-18.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-08-22.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-09-19.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-08-23.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-09-16.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-08-18.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/memory/2026-09-03.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.workbuddy/output/material_digest.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deliverables/product-strategy/CURIS_OPERATING_INTELLIGENCE_UX_EXPLORATION.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `deliverables/product-strategy/CURIS_OPERATING_INTELLIGENCE_RESEARCH.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_CODEX_HTML_EXPLORATION/CONTENT_GROWTH_CODEX_HTML_EXPLORATION_NOTES.md` | RESEARCH / PRODUCT + VISUAL EXPLORATION | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_CODEX_HTML_EXPLORATION/CEO_REVIEW/SCREENSHOT_INDEX.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_CODEX_HTML_EXPLORATION/CEO_REVIEW/SHARED_RECONCILIATION_P1_EVIDENCE.md` | REVIEW / BUSINESS OWNER EVIDENCE | Review | OWNER RECONCILED — READY FOR CEO REVIEW | NO | UNKNOWN | NO / UNKNOWN |
| `MUSIC_WORKSPACE_HTML_EXPLORATION/README.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `knowledge/002_Product_Vision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `knowledge/005_Key_Decisions.md` | UNKNOWN | Deprecated | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `delivery/material_digest.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/workspace-runtime-software.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/workspace-runtime-xhs.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/business.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/workspace-runtime-department.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/decision-room.html` | UNKNOWN | 'pending', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/workspace-runtime-shortvideo.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/_system/runtime-capability.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/coverage-exploration-2026-08-17/10-generic-workspace.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/coverage-exploration-2026-08-17/00-PAGE-STATE-INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/coverage-exploration-2026-08-17/02-business-space.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/coverage-exploration-2026-08-17/02-QUALITY-REVIEW.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/.workbuddy/tmp/verify-decision.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/department-business-work-surface-2026-08-18/CURIS_DEPARTMENT_BUSINESS_WORK_SURFACE_UX_EXPLORATION.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/department-business-work-surface-2026-08-18/02-DELIVERY-SUMMARY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/department-business-work-surface-2026-08-18/01-VISUAL-VALIDATION.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/coverage-exploration-2026-08-17 2/_system/runtime-capability.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/coverage-exploration-2026-08-17 2/coverage-exploration-2026-08-17/00-PAGE-STATE-INVENTORY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `curis-ui-prototype/coverage-exploration-2026-08-17 2/coverage-exploration-2026-08-17/02-business-space.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_OPERATIONAL_VISUAL_EXPLORATION/CURIS_OPERATIONAL_VISUAL_DIRECTION_COMPARISON.md` | REVIEW / VISUAL EXPLORATION | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_OPERATIONAL_VISUAL_EXPLORATION/C_HYBRID_OPERATIONAL/production-overview.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_OPERATIONAL_VISUAL_EXPLORATION/B_DENSE_OPERATIONAL/production-overview.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CURIS_OPERATIONAL_VISUAL_EXPLORATION/A_SPATIAL/production-overview.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_OPEN_SOURCE_DEEP_DIVE.md` | RESEARCH | Draft（已过 Reconciliation 轮 + **Addendum 轮**） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_TECHNOLOGY_MATRIX.md` | RESEARCH | Draft（已过 Reconciliation 轮 + **Addendum 轮**） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_AUTOMATION_AND_AGENT_LAYER.md` | RESEARCH | Draft（已过 Reconciliation 轮 + **Addendum 轮**） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_CAPABILITY_RECOMMENDATION.md` | **RESEARCH — 架构候选（非裁定）** | **Draft — Ready for CEO Review（已过 Reconciliation 轮 + Addendum 轮）** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_SESSION_AND_SECURITY_MODEL.md` | RESEARCH（架构候选，非裁定） | Draft（已过 Reconciliation 轮 + **Addendum 轮**） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/CURIS_BUILT_IN_BROWSER_CAPABILITY_STUDY.md` | **RESEARCH**（非 Current Authority；不修改任何 Curis 产品/Runtime/UI 决定） | **Draft — Ready for CEO Review（已过 Reconciliation 轮 + Addendum 轮）** | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `browser-capability-research/RESEARCH_JOURNAL.md` | RESEARCH | Draft（研究过程日志，非产品裁定；已含 Reconciliation 轮 + **Addendum 轮**） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_USE_CASE_RECONCILIATION.md` | **RESEARCH — RECONCILIATION** | **Draft — Ready for CEO Review** | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_ADDENDUM_2026-09-20_BROWSERSKILL_AND_JEV.md` | **RESEARCH — ADDENDUM**（非裁定） | **Draft — Ready for CEO Review** | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `browser-capability-research/CURIS_BROWSER_LOCAL_CLOUD_HYBRID_OPTIONS.md` | RESEARCH | Draft（已过 Reconciliation 轮） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/04_MACOS_TCC_PERMISSION_MODEL.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/07_PLAYWRIGHT_OFFICIAL_CONSTRAINTS.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `browser-capability-research/evidence/02_LICENSES_VERBATIM.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/05_PLATFORM_TOS_AND_COMPLIANCE.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/08_BROWSER_USE_STAGEHAND_SOURCE_REVIEW.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `browser-capability-research/evidence/06_PLAYWRIGHT_AUTH_AND_SESSION_SEMANTICS.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/10_BROWSERSKILL_AND_JEV_ULTRAFAST_SOURCE_REVIEW.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/03_CHROME_136_REMOTE_DEBUGGING_CHANGE.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/01_SOURCES_INDEX.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `browser-capability-research/evidence/09_AUTHORIZED_CONSOLE_AND_API_GATING.md` | EVIDENCE | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `previews/ui-spec-preview.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/worktrunk/.claude/skills/running-tend/references/review-pr.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/worktrunk/docs/public/demos/twitter/thread-preview.html` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/worktrunk/.github/workflows/tend-review-runs.yaml` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/worktrunk/.github/workflows/tend-review.yaml` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/docs/browser-preview.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/electron/chat/runtime.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/electron/chat/runtime.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/electron/agent-hooks/runtime.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/review-types.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/ReviewProvider.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/ReviewProvider.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/review-navigation.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/review-navigation.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/ReviewSidebarPanel.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/ReviewProvider.client.test.tsx` | UNKNOWN | 'M', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/ReviewCommentCard.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/ReviewSidebar.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/components/ReviewSidebar.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/lib/diff-review-lifecycle.test.ts` | UNKNOWN | 'M', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/lib/diff-review-lifecycle.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/lib/review-eviction.test.ts` | UNKNOWN | 'M', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/lib/symlink-candidates.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/lib/review-eviction.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/lib/close-decision.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/lib/close-decision.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/documents/CandidateRefinement.client.test.tsx` | UNKNOWN | 'finished', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/documents/CompareView.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/documents/CompareView.client.test.tsx` | UNKNOWN | 'done', | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/documents/CandidateRefinement.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/parallel-code/src/documents/CandidateOutputDialog.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/e2e/reviews-tab.spec.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/landing/cloudflare/domain-redirect.wrangler.toml` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/landing/content/docs/guides/review-loop.mdx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/landing/src/app/components/FeaturesSection/components/FeaturePreviewShell.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/landing/src/app/components/FeaturesSection/components/usePreviewScale.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/landing/src/app/components/HeroSection/components/ProductDemo/ProductDemo.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/landing/src/app/components/ProductHuntBadge/ProductHuntBadge.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/landing/src/app/download/StaticAppPreviews.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/components/TrayRuntime.test.tsx` | UNKNOWN | "working", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/components/TrayRuntime.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/components/ReviewerSelect.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/components/ProductExternalLink.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/components/NotificationRuntime.test.tsx` | UNKNOWN | "unread", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/components/diffs/WorkspaceReviewPane.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/components/diffs/WorkspaceReviewPane.test.tsx` | UNKNOWN | "modified", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/hooks/useEditorHandoff.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/hooks/useSessionHandoffMenu.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/hooks/useEditorHandoff.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/lib/session-reviews.ts` | UNKNOWN | "delivered", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/lib/session-reviews.test.ts` | UNKNOWN | "pr_open", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/lib/reviewer-harnesses.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/renderer/lib/preview-mode.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/shared/editor-handoff.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/browser-runtime-link.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/browser-runtime-link.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/agent-browser-runtime.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/browser-runtime-identity.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/browser-runtime-identity.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/editor-handoff.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/editor-handoff.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/frontend/src/main/agent-browser-runtime.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/skillassets/using-ao/commands/preview.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/skillassets/using-ao/commands/review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0114_usage_cost_candidate_canonical_index.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0084_add_session_auto_inject_review.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0130_pr_review_partial.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0044_backfill_review_run_batch_id.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0018_review_run_delivered_at.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0074_activity_kinds_mcp_and_auto_review.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0135_review_launch_id.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0093_review_run_trigger_source.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0023_review_run_retry_cancelled.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0033_add_session_runtime_launch_id.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0017_add_session_preview_url.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0019_add_session_preview_revision.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0042_review_run_unique_per_harness.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0016_review_run_github_review_id.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0131_repair_intermediate_pr_review_certainty.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0106_pr_comment_review_id.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0103_review_run_cdc.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0012_add_review_tables.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0080_review_per_harness.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0091_session_auto_review.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0121_session_reviewer_agent_config.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0021_pr_reviews.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0029_pr_reviews_body.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0134_review_activity_state.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0048_review_agent_session_id.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0092_pr_reviews_target_sha.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0013_review_run_unique_sha.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0049_review_per_harness.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0014_review_run_retry_failed.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/migrations/0020_review_run_unique_pr_sha.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/queries/pr_review_threads.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/queries/pr_reviews.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/storage/sqlite/queries/review.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/backend/internal/adapters/reviewer/pi/assets/ao-pi-reviewer.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/docs/onboarding-contract-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/docs/research/interface-handoff-connectors.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/docs/adr/0002-secure-interactive-reviewer-gateway.md` | UNKNOWN | Accepted (gateway); platform isolation required before adapter rollout | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/cloud/internal/postgres/migrations/00020_review_terminal.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/cloud/internal/postgres/migrations/00016_pull_requests_and_review_runs.sql` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/cloud/scripts/verify-image-contract.sh` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/cloud/scripts/promote-production.sh` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/packages/mobile/scripts/preview-icon.sh` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/packages/mobile/lib/previewFilePath.test.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/packages/mobile/lib/connectRuntime.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `RD_MULTI_AGENT_RESEARCH_LAB/repos/agent-orchestrator/packages/mobile/lib/telemetry/runtime.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/PROJECT_HANDOFF.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/frontend/app/ceo-office/SecretaryDecisionPanel.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/Curis Workspace/08_开发文档/Contract规范.md` | UNKNOWN | current | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/deploy/content-runtime/content_production_adapter.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/deploy/content-runtime/test_aitoearn_stack_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/employee_session_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/skill_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/content_research_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/goal_progress_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/secretary_interaction_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/content_package_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/employee_context_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/runtime_capability_context.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/project_memory_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/tool_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/company_project_runtime.py` | UNKNOWN | str = "active", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/employee_working_memory_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/goal_decision_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/content_routine_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/content_production_connector.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/workflow_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/workflow_recovery_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/app/employee_role_guard_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/tests/test_v21_content_growth_decision_bridge.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/tests/test_employee_template_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/tests/test_phase1a_company_project_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/tests/test_v2_05_decision_to_execution.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/tests/test_phase1a_ai_company_runtime_foundation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/backend/tests/test_v21_content_growth_runtime_enablement.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/shared/product/curis-commercial-system-product-doc.md` | UNKNOWN | Product blueprint for future commercial multi-tenant system. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/shared/architecture/curis-admin-workspace-product-architecture.md` | UNKNOWN | Future blueprint architecture. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/design/ceo-dashboard-product-definition.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/design/phase1c-ceo-office-ui-v3.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/design/phase1c-ceo-office-ui-redesign.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/sprints/sprint-3-role-context-runtime-reference.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/sprints/sprint-0-organization-review.md` | UNKNOWN | Approved. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/sprints/ai-task-executor-mvp-release-candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/company-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/workflow-runtime-contract.md` | UNKNOWN | Phase-5.5 contract prepared for Phase-6 Workflow MVP. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/capability-type-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/memory-retention-isolation-contract.md` | UNKNOWN | V2-02 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/capability-package-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/admin-capability-package-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/workflow-trigger-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/decision-layer-contract.md` | UNKNOWN | V2-01 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-working-memory-contract.md` | UNKNOWN | V2-03 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/pricing-contract.md` | UNKNOWN | Frozen v1 commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/ceo-dashboard-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/official-skill-catalog-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/department-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/decision-to-execution-boundary.md` | UNKNOWN | V2-01 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/workflow-risk-escalation-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/company-package-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/goal-runtime-contract.md` | UNKNOWN | V2-01 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-session-context-contract.md` | UNKNOWN | V2-03 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/billing-rule-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/workflow-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/company-package-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/ai-secretary-ceo-interaction-contract.md` | UNKNOWN | Phase-1.5 S0 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/project-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/quota-rule-contract.md` | UNKNOWN | **Phase-9A P1 · QuotaRule Configuration（实体契约）** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/value-event-type-contract.md` | UNKNOWN | Phase-7.5 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/workflow-retry-recovery-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/dashboard-template-admin-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-role-guard-contract.md` | UNKNOWN | V2-03 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/capability-package-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/pricing-package-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/skill-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-template-instance-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/memory-provenance-freshness-contract.md` | UNKNOWN | V2-02 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/value-event-contract.md` | UNKNOWN | Validated for Phase-7.5 Commercial Validation | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/template-instance-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/commercial-configuration-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/workflow-proactive-reporting-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/billing-domain-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/pricing-rule-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/department-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/company-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/tool-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-seat-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/project-memory-v2-contract.md` | UNKNOWN | V2-02 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/project-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/autonomous-workflow-control-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/xhs-live-read-adapter-contract.md` | UNKNOWN | L2 approval pending | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/admin-plan-management-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/template-catalog-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/ai-secretary-data-retention-contract.md` | UNKNOWN | Phase-1.5 S0 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/employee-seat-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/admin-quota-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/contracts/company-operation-flow-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase3-demo-freeze-report.md` | UNKNOWN | demo freeze ready. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase65-post-workflow-roadmap-review.md` | UNKNOWN | roadmap review and next-gate preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase4-ai-employee-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase55-post-g2-roadmap-review.md` | UNKNOWN | roadmap review and contract preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase1-company-runtime-foundation-report.md` | UNKNOWN | verified implementation complete | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase3-workspace-self-extension-rc.md` | UNKNOWN | RC verification passed with one fix applied in Workspace frontend request header | - Not a Curis product code defect. | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase6-workflow-mvp-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase45-workspace-demo-review-roadmap.md` | UNKNOWN | review and roadmap recommendation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase5-g2-credential-vault-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase9a-commercial-design-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase1b-template-runtime-integration-gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/v2-05-decision-to-execution-first-slice.md` | UNKNOWN | System delivery complete — pending independent Quality and final Security review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/release/phase1a-company-project-runtime-backend.md` | UNKNOWN | implementation report | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/product/curis-ai-company-os-v2-roadmap-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/product/adr0028_phase1_shared_contract_handoff.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/ADR-0019-d1-runtime-role-wiring-boundaries.md` | UNKNOWN | Proposed — for 质量运行席 verification, then 产品规划席 acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/ADR-0018-sprint3-role-context-runtime-unblock.md` | UNKNOWN | Accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/commercial-package-model-v1.md` | UNKNOWN | Frozen for first commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/ADR-0006-role-context-runtime-reference-boundaries.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/commercial-roadmap.md` | UNKNOWN | Frozen v1 commercial package roadmap | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/ADR-0012-evolution-decision-evidence-reliability-boundaries.md` | UNKNOWN | Proposed for quality verification | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/ADR-0029-model-gateway-production-security-boundary.md` | UNKNOWN | Accepted by Security Boundary Seat | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/decisions/ADR-0009-ai-task-executor-mvp-release-candidate-boundaries.md` | UNKNOWN | Accepted by 产品规划席 on 2026-07-06 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/pmo/source-control-baseline-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/team/quality-runtime-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/team/product-planning-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/team/gate-decision-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/team/conversations/CONV-SEAT-PRODUCT-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/review/curis-phase1-product-retrospective.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/review/curis-v2-product-retrospective.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/review/phase9a-employee-seat-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/review/phase9a-capability-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/ai-development-organization/task-runtime-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/ai-development-organization/decision-authority-matrix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/ai-development-organization/runtime-state-observer.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/superpowers/plans/2026-07-14-curis-company-runtime-office-view.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/docs/superpowers/specs/2026-07-14-curis-company-runtime-office-view-design.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/PRODUCT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/.agents/skills/impeccable/reference/product.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/src/app/[lng]/accounts/components/CalendarTimingItem/components/BoxDragPreview.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/src/app/[lng]/ai-social/components/TaskPreview/components/MediaPreviewCard/MediaPreviewCardSkeleton.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/src/utils/region/domain.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/src/components/Chat/Share/SharePreviewModal.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/src/components/draft-box/components/AiBatchGenerateBar/components/ImageStack/hooks/useImageStackPreview.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-web/src/components/PublishDialog/compoents/DesktopPublishContent/PublishDialogDragPreviewLayer.tsx` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/.agents/skills/setup-matt-pocock-skills/domain.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/libs/aws-s3/src/s3.service.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/channels-error-contract.spec.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/platform-review-fixes.spec.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.exception.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.config.ts` | UNKNOWN | z.literal(PlatformStatus.Available), | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business-auth.provider.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business-auth.provider.spec.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.constants.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.interface.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.module.spec.ts` | UNKNOWN | PlatformStatus.Available, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.exception.spec.ts` | UNKNOWN | input.status, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.service.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.module.ts` | UNKNOWN | config.status, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.service.spec.ts` | UNKNOWN | 200, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-ai/src/core/agent/services/agent-runtime.service.ts` | UNKNOWN | AiLogStatus.Success, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/AiToEarn/project/aitoearn-backend/apps/aitoearn-ai/src/core/agent/services/agent-runtime.service.spec.ts` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/uploader/bilibili_uploader/runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/tests/test_bilibili_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/xiaohongshu-upload/references/runtime-requirements.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/xiaohongshu-upload/references/cli-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/kuaishou-upload/references/runtime-requirements.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/kuaishou-upload/references/cli-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/bilibili-upload/references/runtime-requirements.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/bilibili-upload/references/cli-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/douyin-upload/references/runtime-requirements.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/sources/social-auto-upload/skills/douyin-upload/references/cli-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/libs/aws-s3/src/s3.service.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.service.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.module.js` | UNKNOWN | config.status, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.config.js` | UNKNOWN | zod_1.z.literal(platforms_interface_1.PlatformStatus.Available), | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business-auth.provider.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.exception.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.constants.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-server-context/apps/aitoearn-server/src/core/channels/platforms/google-business/google-business.interface.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-ai-context/libs/aws-s3/src/s3.service.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/.curis/content-runtime/aitoearn-ai-context/apps/aitoearn-ai/src/core/agent/services/agent-runtime.service.js` | UNKNOWN | mongodb_1.AiLogStatus.Success, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/knowledge/002_Product_Vision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/knowledge/005_Key_Decisions.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/knowledge/CURRENT_CONTEXT.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/curis_workspace_blueprint/RESEARCH/00-REFERENCE-PRODUCTS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/curis_workspace_blueprint/00-FOUNDATION/02-PRODUCT-PHILOSOPHY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/curis_workspace_blueprint/02-PRODUCT/00-PRODUCT-MODULES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/curis_workspace_blueprint/02-PRODUCT/01-BUSINESS-PACKS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/curis_workspace_blueprint/01-ARCHITECTURE/01-DOMAIN-MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/032_evolution_decision_evidence_reliability_boundaries.md` | UNKNOWN | verified by 质量运行席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/069_model_gateway_production_security_boundary.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/033_evolution_decision_evidence_map.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/045_runtime_role_wiring_first_slice.md` | UNKNOWN | Implementation accepted by 产品规划席 on 2026-07-07 (质量运行席 verification PASS, 48 test | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/075_model_gateway_local_demo_release_candidate_gate.md` | UNKNOWN | "implemented" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase85_commercial_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase7_production_credential_vault_gate.md` | UNKNOWN | Draft for future security gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v2_01_goal_decision_architecture_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v2_04_autonomous_workflow_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/019_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | conducted by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase7_billing_usage_contract_gate.md` | UNKNOWN | Draft for cross-team gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v2_09_ai_workforce_cost_management_contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/070_model_gateway_runtime_secret_guardrails.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v21_company_runtime_office_view.md` | UNKNOWN | `APPROVED_FOR_FRONTEND_IMPLEMENTATION` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase55_admin_readiness_review.md` | UNKNOWN | review-only (零代码改动) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/022_ai_task_executor_mvp_release_candidate_stabilization_docs.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v21_content_growth_runtime_enablement.md` | UNKNOWN | Completed — Quality PASS + Final Security PASS + Product Accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/062_adr0028_phase1_shared_contract.md` | UNKNOWN | "co-signed-with-conditions — 原 Curis Workspace 团队附 5 条件签收 (2026-07-08)" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v2_03_employee_runtime_continuity_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/014_sprint_3_role_context_runtime_reference_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/087_phase35_admin_contract_review_employee_department_templates.md` | UNKNOWN | "APPROVE-WITH-CONDITIONS" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase77_billing_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/031_evolution_decision_evidence_reliability_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v2_05_decision_to_execution_first_slice.md` | UNKNOWN | Completed — Quality PASS + Final Security PASS + Product Accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase1a_ai_company_runtime_foundation.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v2_02_project_memory_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase15_ai_secretary_s0_product_contract.md` | UNKNOWN | Accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/v21_local_media_text_production.md` | UNKNOWN | Product Accepted - closed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/phase5_g2_security_review_kickoff.md` | UNKNOWN | kickoff-draft | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/034_post_v0_1_execution_reliability_closeout_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/021_ai_task_executor_mvp_release_candidate_gate.md` | UNKNOWN | defined by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/015_sprint_3_role_context_runtime_reference_first_slice.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/issues/085_workspace_admin_contract_integration_completion.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_03_employee_runtime_continuity_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_13_ai_secretary_dual_mode_first_slice_review.md` | UNKNOWN | QUALITY_RECHECK_PASS_FINAL_SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_content_growth_runtime_enablement_review.md` | UNKNOWN | FINAL_SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/002_tool_system_v1_6_meta_development_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/029_evolution_decision_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_05_decision_to_execution_first_slice_review.md` | UNKNOWN | QUALITY_SECURITY_REVISION_PASS_PENDING_FINAL_SECURITY_RE_REVIEW | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_12_workflow_recovery_first_slice_review.md` | UNKNOWN | QUALITY_PASS_SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/071_workspace_model_preference_local_e2e_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_local_media_text_production_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/008_sprint_2_unified_task_console_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/074_workspace_company_foundation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/081_workspace_department_activation_ui_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_10_employee_context_assembly_first_slice_review.md` | UNKNOWN | FINAL SECURITY PASS — pending product acceptance | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/073_model_gateway_local_demo_release_closeout_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_xhs_hot_content_research_workflow_review.md` | UNKNOWN | BLOCKED before implementation. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/080_workspace_department_activation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/016_sprint_4_multi_entry_ui_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_local_self_use_sprint_review.md` | UNKNOWN | QUALITY_PASS_PENDING_FINAL_SECURITY_REVIEW | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/011_sprint_3_lightweight_role_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/033_local_demo_verification_automation_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/084_phase4_ai_employee_system_mvp_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/038_d1_runtime_role_wiring_boundary_verification.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/004_sprint_1_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/022_ai_task_executor_mvp_local_demo_release_verification_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/007_sprint_2_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/025_run_evidence_reliability_first_slice_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/061_workspace_capability_integration_phase_1_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/023_ai_task_executor_mvp_v0_1_release_closeout_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/083_workspace_self_extension_mvp_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/phase15_ai_secretary_s1_profile_companion_review.md` | UNKNOWN | ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_08_employee_session_foundation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/034_local_demo_api_smoke_helper_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/027_workflow_error_fallback_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/012_sprint_3_role_profiles_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/026_workflow_error_fallback_observability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/017_ai_task_executor_mvp_readiness_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/070_workspace_model_preference_ui_review.md` | UNKNOWN | READY_FOR_QUALITY_VERIFICATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/031_local_demo_operator_polish_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/069_workspace_tenant_model_preference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/020_ai_task_executor_mvp_release_candidate_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/003_tool_system_v1_8_controlled_self_evolution_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/010_project_memory_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/015_sprint_4_multi_entry_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/067_model_gateway_runtime_secret_guardrails_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_14_goal_progress_ceo_operating_loop_e2e_review.md` | UNKNOWN | FINAL_SECURITY_REVIEW_PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/024_post_v0_1_execution_reliability_boundaries_review.md` | UNKNOWN | PASS by 质量运行席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/063_workspace_official_model_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/phase15_ai_secretary_s0_product_contract_review.md` | UNKNOWN | ACCEPTED | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/014_role_context_runtime_reference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/072_model_gateway_local_demo_release_candidate_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/006_sprint_1_ceo_readable_visualization_polish_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/078_workspace_department_catalog_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/075_workspace_company_foundation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/065_new_api_local_deployment_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_release_closeout_review.md` | UNKNOWN | QUALITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_xhs_local_research_browser_bridge_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/062_workspace_model_gateway_adapter_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/085_phase4_ai_employee_system_rc_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_11_employee_working_memory_first_slice_review.md` | UNKNOWN | SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/028_evolution_decision_evidence_reliability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_02_project_memory_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/079_workspace_department_activation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_xhs_weekly_autonomous_content_loop_review.md` | UNKNOWN | Ready for independent Quality verification. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/066_model_gateway_production_security_boundary_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/009_project_memory_foundation_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/030_post_v0_1_execution_reliability_closeout_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/032_local_demo_operator_release_notes_package_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/019_chinese_operation_console_localization_review.md` | UNKNOWN | READY FOR PRODUCT ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_07_employee_role_guard_preflight_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/001_sprint_0_acceptance_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/064_workspace_official_tool_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_xhs_local_experimental_read_connector_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/005_sprint_1_visualization_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/076_workspace_company_foundation_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/035_project_memory_execution_summary_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_06_project_outcome_memory_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/036_project_memory_execution_summary_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/018_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/013_role_context_runtime_reference_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_01_goal_decision_architecture_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/077_workspace_company_department_catalog_summary_review.md` | UNKNOWN | READY_FOR_QUALITY_RECHECK | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/021_ai_task_executor_mvp_release_candidate_stabilization_docs_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v2_04_autonomous_workflow_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/082_workspace_admin_contract_integration_completion_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/v21_local_content_department_full_loop_review.md` | UNKNOWN | POST_CLICK_SIGNAL_QUALITY_PASS_SECURITY_AND_REAL_CLOSURE_PENDING | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/037_redesign_v2_architecture_review_decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/ai-secretary-planning/reviews/068_workspace_tenant_model_preference_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/PROJECT_STATUS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/PROJECT_HANDOFF.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/Curis Workspace/08_开发文档/Contract规范.md` | UNKNOWN | current | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/app/skill_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/app/runtime_capability_context.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/app/tool_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/app/company_project_runtime.py` | UNKNOWN | str = "active", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/app/workflow_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/tests/test_employee_template_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/tests/test_phase1a_company_project_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/backend/tests/test_phase1a_ai_company_runtime_foundation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/shared/product/curis-commercial-system-product-doc.md` | UNKNOWN | Product blueprint for future commercial multi-tenant system. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/shared/architecture/curis-admin-workspace-product-architecture.md` | UNKNOWN | Future blueprint architecture. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/design/ceo-dashboard-product-definition.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/design/phase1c-ceo-office-ui-v3.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/design/phase1c-ceo-office-ui-redesign.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/sprints/sprint-3-role-context-runtime-reference.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/sprints/sprint-0-organization-review.md` | UNKNOWN | Approved. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/sprints/ai-task-executor-mvp-release-candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/company-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/workflow-runtime-contract.md` | UNKNOWN | Phase-5.5 contract prepared for Phase-6 Workflow MVP. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/capability-type-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/capability-package-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/admin-capability-package-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/workflow-trigger-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/pricing-contract.md` | UNKNOWN | Frozen v1 commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/ceo-dashboard-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/official-skill-catalog-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/department-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/company-package-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/billing-rule-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/workflow-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/company-package-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/project-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/quota-rule-contract.md` | UNKNOWN | **Phase-9A P1 · QuotaRule Configuration（实体契约）** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/value-event-type-contract.md` | UNKNOWN | Phase-7.5 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/dashboard-template-admin-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/capability-package-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/pricing-package-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/skill-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/employee-template-instance-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/value-event-contract.md` | UNKNOWN | Validated for Phase-7.5 Commercial Validation | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/template-instance-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/commercial-configuration-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/billing-domain-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/pricing-rule-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/department-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/employee-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/company-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/tool-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/employee-seat-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/project-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/employee-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/admin-plan-management-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/template-catalog-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/employee-seat-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/admin-quota-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/contracts/company-operation-flow-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase3-demo-freeze-report.md` | UNKNOWN | demo freeze ready. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase65-post-workflow-roadmap-review.md` | UNKNOWN | roadmap review and next-gate preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase4-ai-employee-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase55-post-g2-roadmap-review.md` | UNKNOWN | roadmap review and contract preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase1-company-runtime-foundation-report.md` | UNKNOWN | verified implementation complete | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase3-workspace-self-extension-rc.md` | UNKNOWN | RC verification passed with one fix applied in Workspace frontend request header | - Not a Curis product code defect. | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase6-workflow-mvp-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase45-workspace-demo-review-roadmap.md` | UNKNOWN | review and roadmap recommendation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase5-g2-credential-vault-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase9a-commercial-design-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase1b-template-runtime-integration-gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/release/phase1a-company-project-runtime-backend.md` | UNKNOWN | implementation report | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/product/adr0028_phase1_shared_contract_handoff.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/ADR-0019-d1-runtime-role-wiring-boundaries.md` | UNKNOWN | Proposed — for 质量运行席 verification, then 产品规划席 acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/ADR-0018-sprint3-role-context-runtime-unblock.md` | UNKNOWN | Accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/commercial-package-model-v1.md` | UNKNOWN | Frozen for first commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/ADR-0006-role-context-runtime-reference-boundaries.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/commercial-roadmap.md` | UNKNOWN | Frozen v1 commercial package roadmap | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/ADR-0012-evolution-decision-evidence-reliability-boundaries.md` | UNKNOWN | Proposed for quality verification | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/ADR-0029-model-gateway-production-security-boundary.md` | UNKNOWN | Accepted by Security Boundary Seat | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/decisions/ADR-0009-ai-task-executor-mvp-release-candidate-boundaries.md` | UNKNOWN | Accepted by 产品规划席 on 2026-07-06 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/pmo/source-control-baseline-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/team/quality-runtime-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/team/product-planning-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/team/gate-decision-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/team/conversations/CONV-SEAT-PRODUCT-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/review/phase9a-employee-seat-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/review/phase9a-capability-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/ai-development-organization/task-runtime-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/ai-development-organization/decision-authority-matrix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/docs/ai-development-organization/runtime-state-observer.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/knowledge/002_Product_Vision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/knowledge/005_Key_Decisions.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/curis_workspace_blueprint/RESEARCH/00-REFERENCE-PRODUCTS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/curis_workspace_blueprint/00-FOUNDATION/02-PRODUCT-PHILOSOPHY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/curis_workspace_blueprint/02-PRODUCT/00-PRODUCT-MODULES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/curis_workspace_blueprint/02-PRODUCT/01-BUSINESS-PACKS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/curis_workspace_blueprint/01-ARCHITECTURE/01-DOMAIN-MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/032_evolution_decision_evidence_reliability_boundaries.md` | UNKNOWN | verified by 质量运行席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/069_model_gateway_production_security_boundary.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/033_evolution_decision_evidence_map.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/045_runtime_role_wiring_first_slice.md` | UNKNOWN | Implementation accepted by 产品规划席 on 2026-07-07 (质量运行席 verification PASS, 48 test | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/075_model_gateway_local_demo_release_candidate_gate.md` | UNKNOWN | "implemented" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/phase85_commercial_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/phase7_production_credential_vault_gate.md` | UNKNOWN | Draft for future security gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/019_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | conducted by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/phase7_billing_usage_contract_gate.md` | UNKNOWN | Draft for cross-team gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/070_model_gateway_runtime_secret_guardrails.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/phase55_admin_readiness_review.md` | UNKNOWN | review-only (零代码改动) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/022_ai_task_executor_mvp_release_candidate_stabilization_docs.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/062_adr0028_phase1_shared_contract.md` | UNKNOWN | "co-signed-with-conditions — 原 Curis Workspace 团队附 5 条件签收 (2026-07-08)" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/014_sprint_3_role_context_runtime_reference_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/087_phase35_admin_contract_review_employee_department_templates.md` | UNKNOWN | "APPROVE-WITH-CONDITIONS" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/phase77_billing_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/031_evolution_decision_evidence_reliability_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/phase1a_ai_company_runtime_foundation.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/phase5_g2_security_review_kickoff.md` | UNKNOWN | kickoff-draft | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/034_post_v0_1_execution_reliability_closeout_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/021_ai_task_executor_mvp_release_candidate_gate.md` | UNKNOWN | defined by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/015_sprint_3_role_context_runtime_reference_first_slice.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/issues/085_workspace_admin_contract_integration_completion.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/002_tool_system_v1_6_meta_development_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/029_evolution_decision_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/071_workspace_model_preference_local_e2e_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/008_sprint_2_unified_task_console_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/074_workspace_company_foundation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/081_workspace_department_activation_ui_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/073_model_gateway_local_demo_release_closeout_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/080_workspace_department_activation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/016_sprint_4_multi_entry_ui_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/011_sprint_3_lightweight_role_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/033_local_demo_verification_automation_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/084_phase4_ai_employee_system_mvp_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/038_d1_runtime_role_wiring_boundary_verification.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/004_sprint_1_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/022_ai_task_executor_mvp_local_demo_release_verification_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/007_sprint_2_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/025_run_evidence_reliability_first_slice_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/061_workspace_capability_integration_phase_1_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/023_ai_task_executor_mvp_v0_1_release_closeout_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/083_workspace_self_extension_mvp_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/034_local_demo_api_smoke_helper_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/027_workflow_error_fallback_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/012_sprint_3_role_profiles_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/026_workflow_error_fallback_observability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/017_ai_task_executor_mvp_readiness_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/070_workspace_model_preference_ui_review.md` | UNKNOWN | READY_FOR_QUALITY_VERIFICATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/031_local_demo_operator_polish_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/069_workspace_tenant_model_preference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/020_ai_task_executor_mvp_release_candidate_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/003_tool_system_v1_8_controlled_self_evolution_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/010_project_memory_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/015_sprint_4_multi_entry_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/067_model_gateway_runtime_secret_guardrails_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/024_post_v0_1_execution_reliability_boundaries_review.md` | UNKNOWN | PASS by 质量运行席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/063_workspace_official_model_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/014_role_context_runtime_reference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/072_model_gateway_local_demo_release_candidate_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/006_sprint_1_ceo_readable_visualization_polish_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/078_workspace_department_catalog_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/075_workspace_company_foundation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/065_new_api_local_deployment_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/062_workspace_model_gateway_adapter_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/085_phase4_ai_employee_system_rc_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/028_evolution_decision_evidence_reliability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/079_workspace_department_activation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/066_model_gateway_production_security_boundary_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/009_project_memory_foundation_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/030_post_v0_1_execution_reliability_closeout_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/032_local_demo_operator_release_notes_package_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/019_chinese_operation_console_localization_review.md` | UNKNOWN | READY FOR PRODUCT ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/001_sprint_0_acceptance_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/064_workspace_official_tool_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/005_sprint_1_visualization_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/076_workspace_company_foundation_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/035_project_memory_execution_summary_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/phase1c_company_project_bootstrap_ui_review.md` | UNKNOWN | ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/036_project_memory_execution_summary_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/phase1c_ceo_office_ui_first_slice_review.md` | UNKNOWN | ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/018_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/013_role_context_runtime_reference_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/077_workspace_company_department_catalog_summary_review.md` | UNKNOWN | READY_FOR_QUALITY_RECHECK | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/021_ai_task_executor_mvp_release_candidate_stabilization_docs_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/082_workspace_admin_contract_integration_completion_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/037_redesign_v2_architecture_review_decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-company-project-bootstrap-ui/reviews/068_workspace_tenant_model_preference_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/PROJECT_HANDOFF.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/frontend/app/ceo-office/SecretaryDecisionPanel.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/frontend/app/company-runtime-view/CompanyRuntimeView.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/Curis Workspace/08_开发文档/Contract规范.md` | UNKNOWN | current | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/deploy/content-runtime/content_production_adapter.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/deploy/content-runtime/test_aitoearn_stack_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/employee_session_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/skill_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/content_research_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/goal_progress_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/secretary_interaction_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/content_package_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/employee_context_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/runtime_capability_context.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/project_memory_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/tool_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/company_project_runtime.py` | UNKNOWN | str = "active", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/employee_working_memory_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/goal_decision_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/content_routine_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/content_production_connector.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/workflow_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/workflow_recovery_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/app/employee_role_guard_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/tests/test_v21_content_growth_decision_bridge.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/tests/test_employee_template_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/tests/test_phase1a_company_project_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/tests/test_v2_05_decision_to_execution.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/tests/test_phase1a_ai_company_runtime_foundation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/backend/tests/test_v21_content_growth_runtime_enablement.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/shared/product/curis-commercial-system-product-doc.md` | UNKNOWN | Product blueprint for future commercial multi-tenant system. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/shared/architecture/curis-admin-workspace-product-architecture.md` | UNKNOWN | Future blueprint architecture. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/design/ceo-dashboard-product-definition.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/design/phase1c-ceo-office-ui-v3.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/design/phase1c-ceo-office-ui-redesign.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/sprints/sprint-3-role-context-runtime-reference.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/sprints/sprint-0-organization-review.md` | UNKNOWN | Approved. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/sprints/ai-task-executor-mvp-release-candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/company-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/workflow-runtime-contract.md` | UNKNOWN | Phase-5.5 contract prepared for Phase-6 Workflow MVP. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/capability-type-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/memory-retention-isolation-contract.md` | UNKNOWN | V2-02 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/capability-package-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/admin-capability-package-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/workflow-trigger-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/decision-layer-contract.md` | UNKNOWN | V2-01 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-working-memory-contract.md` | UNKNOWN | V2-03 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/pricing-contract.md` | UNKNOWN | Frozen v1 commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/ceo-dashboard-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/official-skill-catalog-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/department-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/decision-to-execution-boundary.md` | UNKNOWN | V2-01 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/workflow-risk-escalation-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/company-package-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/goal-runtime-contract.md` | UNKNOWN | V2-01 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-session-context-contract.md` | UNKNOWN | V2-03 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/billing-rule-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/workflow-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/company-package-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/ai-secretary-ceo-interaction-contract.md` | UNKNOWN | Phase-1.5 S0 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/project-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/quota-rule-contract.md` | UNKNOWN | **Phase-9A P1 · QuotaRule Configuration（实体契约）** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/value-event-type-contract.md` | UNKNOWN | Phase-7.5 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/workflow-retry-recovery-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/dashboard-template-admin-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-role-guard-contract.md` | UNKNOWN | V2-03 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/capability-package-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/pricing-package-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/skill-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-template-instance-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/memory-provenance-freshness-contract.md` | UNKNOWN | V2-02 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/value-event-contract.md` | UNKNOWN | Validated for Phase-7.5 Commercial Validation | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/template-instance-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/commercial-configuration-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/workflow-proactive-reporting-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/billing-domain-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/pricing-rule-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/department-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/company-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/tool-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-seat-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/project-memory-v2-contract.md` | UNKNOWN | V2-02 Product Contract | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/project-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/autonomous-workflow-control-contract.md` | UNKNOWN | V2-04 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/xhs-live-read-adapter-contract.md` | UNKNOWN | L2 approval pending | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/admin-plan-management-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/template-catalog-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/ai-secretary-data-retention-contract.md` | UNKNOWN | Phase-1.5 S0 Product Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/employee-seat-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/admin-quota-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/contracts/company-operation-flow-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase3-demo-freeze-report.md` | UNKNOWN | demo freeze ready. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase65-post-workflow-roadmap-review.md` | UNKNOWN | roadmap review and next-gate preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase4-ai-employee-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase55-post-g2-roadmap-review.md` | UNKNOWN | roadmap review and contract preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase1-company-runtime-foundation-report.md` | UNKNOWN | verified implementation complete | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase3-workspace-self-extension-rc.md` | UNKNOWN | RC verification passed with one fix applied in Workspace frontend request header | - Not a Curis product code defect. | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase6-workflow-mvp-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase45-workspace-demo-review-roadmap.md` | UNKNOWN | review and roadmap recommendation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase5-g2-credential-vault-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/v21-local-self-use-release-candidate.md` | UNKNOWN | 本机启动可用性修复待质量复验。 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase9a-commercial-design-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase1b-template-runtime-integration-gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/v2-05-decision-to-execution-first-slice.md` | UNKNOWN | System delivery complete — pending independent Quality and final Security review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/release/phase1a-company-project-runtime-backend.md` | UNKNOWN | implementation report | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/product/curis-ai-company-os-v2-roadmap-review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/product/adr0028_phase1_shared_contract_handoff.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/ADR-0019-d1-runtime-role-wiring-boundaries.md` | UNKNOWN | Proposed — for 质量运行席 verification, then 产品规划席 acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/ADR-0018-sprint3-role-context-runtime-unblock.md` | UNKNOWN | Accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/commercial-package-model-v1.md` | UNKNOWN | Frozen for first commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/ADR-0006-role-context-runtime-reference-boundaries.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/commercial-roadmap.md` | UNKNOWN | Frozen v1 commercial package roadmap | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/ADR-0012-evolution-decision-evidence-reliability-boundaries.md` | UNKNOWN | Proposed for quality verification | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/ADR-0029-model-gateway-production-security-boundary.md` | UNKNOWN | Accepted by Security Boundary Seat | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/decisions/ADR-0009-ai-task-executor-mvp-release-candidate-boundaries.md` | UNKNOWN | Accepted by 产品规划席 on 2026-07-06 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/pmo/source-control-baseline-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/team/quality-runtime-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/team/product-planning-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/team/gate-decision-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/team/conversations/CONV-SEAT-PRODUCT-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/review/curis-phase1-product-retrospective.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/review/curis-v2-product-retrospective.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/review/phase9a-employee-seat-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/review/phase9a-capability-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/ai-development-organization/task-runtime-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/ai-development-organization/decision-authority-matrix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/ai-development-organization/runtime-state-observer.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/superpowers/plans/2026-07-14-curis-company-runtime-office-view.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/docs/superpowers/specs/2026-07-14-curis-company-runtime-office-view-design.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/knowledge/002_Product_Vision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/knowledge/005_Key_Decisions.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/curis_workspace_blueprint/RESEARCH/00-REFERENCE-PRODUCTS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/curis_workspace_blueprint/00-FOUNDATION/02-PRODUCT-PHILOSOPHY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/curis_workspace_blueprint/02-PRODUCT/00-PRODUCT-MODULES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/curis_workspace_blueprint/02-PRODUCT/01-BUSINESS-PACKS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/curis_workspace_blueprint/01-ARCHITECTURE/01-DOMAIN-MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/032_evolution_decision_evidence_reliability_boundaries.md` | UNKNOWN | verified by 质量运行席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/069_model_gateway_production_security_boundary.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/033_evolution_decision_evidence_map.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/045_runtime_role_wiring_first_slice.md` | UNKNOWN | Implementation accepted by 产品规划席 on 2026-07-07 (质量运行席 verification PASS, 48 test | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/075_model_gateway_local_demo_release_candidate_gate.md` | UNKNOWN | "implemented" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase85_commercial_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase7_production_credential_vault_gate.md` | UNKNOWN | Draft for future security gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v2_01_goal_decision_architecture_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v2_04_autonomous_workflow_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/019_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | conducted by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase7_billing_usage_contract_gate.md` | UNKNOWN | Draft for cross-team gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v2_09_ai_workforce_cost_management_contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/070_model_gateway_runtime_secret_guardrails.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v21_company_runtime_office_view.md` | UNKNOWN | `PRODUCT_ACCEPTED - CLOSED` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase55_admin_readiness_review.md` | UNKNOWN | review-only (零代码改动) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/022_ai_task_executor_mvp_release_candidate_stabilization_docs.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v21_content_growth_runtime_enablement.md` | UNKNOWN | Completed — Quality PASS + Final Security PASS + Product Accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/062_adr0028_phase1_shared_contract.md` | UNKNOWN | "co-signed-with-conditions — 原 Curis Workspace 团队附 5 条件签收 (2026-07-08)" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v2_03_employee_runtime_continuity_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/014_sprint_3_role_context_runtime_reference_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/087_phase35_admin_contract_review_employee_department_templates.md` | UNKNOWN | "APPROVE-WITH-CONDITIONS" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase77_billing_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/031_evolution_decision_evidence_reliability_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v2_05_decision_to_execution_first_slice.md` | UNKNOWN | Completed — Quality PASS + Final Security PASS + Product Accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase1a_ai_company_runtime_foundation.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v2_02_project_memory_contract.md` | UNKNOWN | Completed — product accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase15_ai_secretary_s0_product_contract.md` | UNKNOWN | Accepted | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/v21_local_media_text_production.md` | UNKNOWN | Product Accepted - closed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/phase5_g2_security_review_kickoff.md` | UNKNOWN | kickoff-draft | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/034_post_v0_1_execution_reliability_closeout_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/021_ai_task_executor_mvp_release_candidate_gate.md` | UNKNOWN | defined by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/015_sprint_3_role_context_runtime_reference_first_slice.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/issues/085_workspace_admin_contract_integration_completion.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_03_employee_runtime_continuity_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_13_ai_secretary_dual_mode_first_slice_review.md` | UNKNOWN | QUALITY_RECHECK_PASS_FINAL_SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_content_growth_runtime_enablement_review.md` | UNKNOWN | FINAL_SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/002_tool_system_v1_6_meta_development_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/029_evolution_decision_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_05_decision_to_execution_first_slice_review.md` | UNKNOWN | QUALITY_SECURITY_REVISION_PASS_PENDING_FINAL_SECURITY_RE_REVIEW | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_12_workflow_recovery_first_slice_review.md` | UNKNOWN | QUALITY_PASS_SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/071_workspace_model_preference_local_e2e_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_local_media_text_production_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/008_sprint_2_unified_task_console_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/074_workspace_company_foundation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/081_workspace_department_activation_ui_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_10_employee_context_assembly_first_slice_review.md` | UNKNOWN | FINAL SECURITY PASS — pending product acceptance | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_local_self_use_release_usability_review.md` | UNKNOWN | `QUALITY_BLOCKED - PROTECTED_RUNTIME_EVIDENCE_REQUIRED` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/073_model_gateway_local_demo_release_closeout_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_xhs_hot_content_research_workflow_review.md` | UNKNOWN | BLOCKED before implementation. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/080_workspace_department_activation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/016_sprint_4_multi_entry_ui_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_local_self_use_sprint_review.md` | UNKNOWN | QUALITY_PASS_PENDING_FINAL_SECURITY_REVIEW | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/011_sprint_3_lightweight_role_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/033_local_demo_verification_automation_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/084_phase4_ai_employee_system_mvp_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/038_d1_runtime_role_wiring_boundary_verification.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/004_sprint_1_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/022_ai_task_executor_mvp_local_demo_release_verification_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/007_sprint_2_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/025_run_evidence_reliability_first_slice_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/061_workspace_capability_integration_phase_1_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/023_ai_task_executor_mvp_v0_1_release_closeout_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/083_workspace_self_extension_mvp_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_four_core_surfaces_ia_ui_execution_review.md` | UNKNOWN | `PRODUCT_ACCEPTED / CLOSED` | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/phase15_ai_secretary_s1_profile_companion_review.md` | UNKNOWN | ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_08_employee_session_foundation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/034_local_demo_api_smoke_helper_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/027_workflow_error_fallback_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_local_self_use_release_preparation_review.md` | UNKNOWN | `ACCEPTED` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/012_sprint_3_role_profiles_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/026_workflow_error_fallback_observability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/017_ai_task_executor_mvp_readiness_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/070_workspace_model_preference_ui_review.md` | UNKNOWN | READY_FOR_QUALITY_VERIFICATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/031_local_demo_operator_polish_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/069_workspace_tenant_model_preference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/020_ai_task_executor_mvp_release_candidate_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/003_tool_system_v1_8_controlled_self_evolution_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/010_project_memory_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/015_sprint_4_multi_entry_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/067_model_gateway_runtime_secret_guardrails_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_14_goal_progress_ceo_operating_loop_e2e_review.md` | UNKNOWN | FINAL_SECURITY_REVIEW_PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_ceo_headquarters_navigation_and_appearance_review.md` | UNKNOWN | `QUALITY_PASS_RETAINED - PRODUCT_ACCEPTANCE_WITHDRAWN` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/024_post_v0_1_execution_reliability_boundaries_review.md` | UNKNOWN | PASS by 质量运行席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/063_workspace_official_model_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/phase15_ai_secretary_s0_product_contract_review.md` | UNKNOWN | ACCEPTED | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/014_role_context_runtime_reference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/072_model_gateway_local_demo_release_candidate_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/006_sprint_1_ceo_readable_visualization_polish_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/078_workspace_department_catalog_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/075_workspace_company_foundation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/065_new_api_local_deployment_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_release_closeout_review.md` | UNKNOWN | QUALITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_xhs_local_research_browser_bridge_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/062_workspace_model_gateway_adapter_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/085_phase4_ai_employee_system_rc_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_11_employee_working_memory_first_slice_review.md` | UNKNOWN | SECURITY_PASS_PENDING_PRODUCT_ACCEPTANCE | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/028_evolution_decision_evidence_reliability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_02_project_memory_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/079_workspace_department_activation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_xhs_weekly_autonomous_content_loop_review.md` | UNKNOWN | Ready for independent Quality verification. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/066_model_gateway_production_security_boundary_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/009_project_memory_foundation_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/030_post_v0_1_execution_reliability_closeout_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/032_local_demo_operator_release_notes_package_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/019_chinese_operation_console_localization_review.md` | UNKNOWN | READY FOR PRODUCT ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_07_employee_role_guard_preflight_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/001_sprint_0_acceptance_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/064_workspace_official_tool_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_xhs_local_experimental_read_connector_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/005_sprint_1_visualization_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/076_workspace_company_foundation_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/035_project_memory_execution_summary_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_06_project_outcome_memory_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/036_project_memory_execution_summary_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_company_runtime_office_view_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/018_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/013_role_context_runtime_reference_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_frontend_visual_quality_rework_review.md` | UNKNOWN | `PRODUCT_ACCEPTED - CLOSED` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_01_goal_decision_architecture_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/077_workspace_company_department_catalog_summary_review.md` | UNKNOWN | READY_FOR_QUALITY_RECHECK | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/021_ai_task_executor_mvp_release_candidate_stabilization_docs_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v2_04_autonomous_workflow_contract_review.md` | UNKNOWN | PRODUCT_ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/082_workspace_admin_contract_integration_completion_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/v21_local_content_department_full_loop_review.md` | UNKNOWN | POST_CLICK_SIGNAL_QUALITY_PASS_SECURITY_AND_REAL_CLOSURE_PENDING | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/037_redesign_v2_architecture_review_decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/company-runtime-office-view/reviews/068_workspace_tenant_model_preference_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/PROJECT_STATUS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/PROJECT_HANDOFF.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/Curis Workspace/08_开发文档/Contract规范.md` | UNKNOWN | current | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/app/skill_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/app/runtime_capability_context.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/app/tool_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/app/company_project_runtime.py` | UNKNOWN | str = "active", | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/app/workflow_runtime.py` | UNKNOWN | str, | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/tests/test_employee_template_contract.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/tests/test_phase1a_company_project_runtime.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/backend/tests/test_phase1a_ai_company_runtime_foundation.py` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/shared/product/curis-commercial-system-product-doc.md` | UNKNOWN | Product blueprint for future commercial multi-tenant system. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/shared/architecture/curis-admin-workspace-product-architecture.md` | UNKNOWN | Future blueprint architecture. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/design/ceo-dashboard-product-definition.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/design/phase1c-ceo-office-ui-v3.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/design/phase1c-ceo-office-ui-redesign.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/sprints/sprint-3-role-context-runtime-reference.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/sprints/sprint-0-organization-review.md` | UNKNOWN | Approved. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/sprints/ai-task-executor-mvp-release-candidate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/company-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/workflow-runtime-contract.md` | UNKNOWN | Phase-5.5 contract prepared for Phase-6 Workflow MVP. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/capability-type-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/capability-package-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/admin-capability-package-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/workflow-trigger-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/pricing-contract.md` | UNKNOWN | Frozen v1 commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/ceo-dashboard-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/official-skill-catalog-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/department-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/company-package-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/billing-rule-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/workflow-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/company-package-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/project-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/quota-rule-contract.md` | UNKNOWN | **Phase-9A P1 · QuotaRule Configuration（实体契约）** | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/value-event-type-contract.md` | UNKNOWN | Phase-7.5 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/dashboard-template-admin-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/capability-package-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/pricing-package-contract.md` | UNKNOWN | **Phase-8.5 Commercial Readiness** · 纯契约（无代码） | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/skill-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/employee-template-instance-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/value-event-contract.md` | UNKNOWN | Validated for Phase-7.5 Commercial Validation | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/template-instance-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/commercial-configuration-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/billing-domain-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/pricing-rule-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/department-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/employee-template-contract.md` | UNKNOWN | Phase-3.5 contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/company-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/tool-runtime-contract.md` | UNKNOWN | Phase 1A backend foundation contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/employee-seat-contract.md` | UNKNOWN | Phase-7.7 Billing Readiness Contract | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/project-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/employee-lifecycle-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/admin-plan-management-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/template-catalog-runtime-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/employee-seat-commercial-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/admin-quota-contract.md` | UNKNOWN | Phase-7.7 design only | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/contracts/company-operation-flow-contract.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase3-demo-freeze-report.md` | UNKNOWN | demo freeze ready. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase65-post-workflow-roadmap-review.md` | UNKNOWN | roadmap review and next-gate preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase4-ai-employee-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase55-post-g2-roadmap-review.md` | UNKNOWN | roadmap review and contract preparation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase1-company-runtime-foundation-report.md` | UNKNOWN | verified implementation complete | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase3-workspace-self-extension-rc.md` | UNKNOWN | RC verification passed with one fix applied in Workspace frontend request header | - Not a Curis product code defect. | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase6-workflow-mvp-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase45-workspace-demo-review-roadmap.md` | UNKNOWN | review and roadmap recommendation only. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase5-g2-credential-vault-demo-freeze-report.md` | UNKNOWN | demo freeze verified, pending product acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase9a-commercial-design-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase1b-template-runtime-integration-gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/release/phase1a-company-project-runtime-backend.md` | UNKNOWN | implementation report | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/product/adr0028_phase1_shared_contract_handoff.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/ADR-0019-d1-runtime-role-wiring-boundaries.md` | UNKNOWN | Proposed — for 质量运行席 verification, then 产品规划席 acceptance. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/ADR-0018-sprint3-role-context-runtime-unblock.md` | UNKNOWN | Accepted | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/commercial-package-model-v1.md` | UNKNOWN | Frozen for first commercial package model | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/ADR-0006-role-context-runtime-reference-boundaries.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/commercial-roadmap.md` | UNKNOWN | Frozen v1 commercial package roadmap | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/ADR-0012-evolution-decision-evidence-reliability-boundaries.md` | UNKNOWN | Proposed for quality verification | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/ADR-0029-model-gateway-production-security-boundary.md` | UNKNOWN | Accepted by Security Boundary Seat | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/decisions/ADR-0009-ai-task-executor-mvp-release-candidate-boundaries.md` | UNKNOWN | Accepted by 产品规划席 on 2026-07-06 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/pmo/source-control-baseline-freeze.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/team/quality-runtime-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/team/product-planning-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/team/gate-decision-seat-role.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/team/conversations/CONV-SEAT-PRODUCT-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/review/phase9a-employee-seat-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/review/phase9a-capability-meter-review.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/ai-development-organization/task-runtime-engine.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/ai-development-organization/decision-authority-matrix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/docs/ai-development-organization/runtime-state-observer.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/knowledge/002_Product_Vision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/knowledge/005_Key_Decisions.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/curis_workspace_blueprint/RESEARCH/00-REFERENCE-PRODUCTS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/curis_workspace_blueprint/00-FOUNDATION/02-PRODUCT-PHILOSOPHY.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/curis_workspace_blueprint/02-PRODUCT/00-PRODUCT-MODULES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/curis_workspace_blueprint/02-PRODUCT/01-BUSINESS-PACKS.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/curis_workspace_blueprint/01-ARCHITECTURE/01-DOMAIN-MODEL.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/032_evolution_decision_evidence_reliability_boundaries.md` | UNKNOWN | verified by 质量运行席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/069_model_gateway_production_security_boundary.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/033_evolution_decision_evidence_map.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/045_runtime_role_wiring_first_slice.md` | UNKNOWN | Implementation accepted by 产品规划席 on 2026-07-07 (质量运行席 verification PASS, 48 test | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/075_model_gateway_local_demo_release_candidate_gate.md` | UNKNOWN | "implemented" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/phase85_commercial_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/phase7_production_credential_vault_gate.md` | UNKNOWN | Draft for future security gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/019_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | conducted by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/phase7_billing_usage_contract_gate.md` | UNKNOWN | Draft for cross-team gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/070_model_gateway_runtime_secret_guardrails.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/phase55_admin_readiness_review.md` | UNKNOWN | review-only (零代码改动) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/022_ai_task_executor_mvp_release_candidate_stabilization_docs.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/062_adr0028_phase1_shared_contract.md` | UNKNOWN | "co-signed-with-conditions — 原 Curis Workspace 团队附 5 条件签收 (2026-07-08)" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/014_sprint_3_role_context_runtime_reference_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/087_phase35_admin_contract_review_employee_department_templates.md` | UNKNOWN | "APPROVE-WITH-CONDITIONS" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/phase77_billing_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/031_evolution_decision_evidence_reliability_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/phase1a_ai_company_runtime_foundation.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/phase5_g2_security_review_kickoff.md` | UNKNOWN | kickoff-draft | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/034_post_v0_1_execution_reliability_closeout_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/021_ai_task_executor_mvp_release_candidate_gate.md` | UNKNOWN | defined by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/015_sprint_3_role_context_runtime_reference_first_slice.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/issues/085_workspace_admin_contract_integration_completion.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/002_tool_system_v1_6_meta_development_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/029_evolution_decision_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/071_workspace_model_preference_local_e2e_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/008_sprint_2_unified_task_console_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/074_workspace_company_foundation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/081_workspace_department_activation_ui_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/073_model_gateway_local_demo_release_closeout_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/080_workspace_department_activation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/016_sprint_4_multi_entry_ui_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/011_sprint_3_lightweight_role_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/033_local_demo_verification_automation_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/084_phase4_ai_employee_system_mvp_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/038_d1_runtime_role_wiring_boundary_verification.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/004_sprint_1_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/022_ai_task_executor_mvp_local_demo_release_verification_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/007_sprint_2_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/025_run_evidence_reliability_first_slice_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/061_workspace_capability_integration_phase_1_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/023_ai_task_executor_mvp_v0_1_release_closeout_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/083_workspace_self_extension_mvp_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/034_local_demo_api_smoke_helper_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/027_workflow_error_fallback_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/012_sprint_3_role_profiles_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/026_workflow_error_fallback_observability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/017_ai_task_executor_mvp_readiness_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/070_workspace_model_preference_ui_review.md` | UNKNOWN | READY_FOR_QUALITY_VERIFICATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/031_local_demo_operator_polish_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/069_workspace_tenant_model_preference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/020_ai_task_executor_mvp_release_candidate_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/003_tool_system_v1_8_controlled_self_evolution_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/010_project_memory_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/015_sprint_4_multi_entry_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/067_model_gateway_runtime_secret_guardrails_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/024_post_v0_1_execution_reliability_boundaries_review.md` | UNKNOWN | PASS by 质量运行席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/063_workspace_official_model_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/014_role_context_runtime_reference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/072_model_gateway_local_demo_release_candidate_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/006_sprint_1_ceo_readable_visualization_polish_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/078_workspace_department_catalog_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/075_workspace_company_foundation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/065_new_api_local_deployment_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/062_workspace_model_gateway_adapter_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/085_phase4_ai_employee_system_rc_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/028_evolution_decision_evidence_reliability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/079_workspace_department_activation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/066_model_gateway_production_security_boundary_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/009_project_memory_foundation_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/030_post_v0_1_execution_reliability_closeout_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/032_local_demo_operator_release_notes_package_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/019_chinese_operation_console_localization_review.md` | UNKNOWN | READY FOR PRODUCT ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/001_sprint_0_acceptance_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/064_workspace_official_tool_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/005_sprint_1_visualization_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/076_workspace_company_foundation_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/035_project_memory_execution_summary_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/036_project_memory_execution_summary_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/phase1c_ceo_office_ui_first_slice_review.md` | UNKNOWN | ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/018_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/013_role_context_runtime_reference_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/077_workspace_company_department_catalog_summary_review.md` | UNKNOWN | READY_FOR_QUALITY_RECHECK | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/021_ai_task_executor_mvp_release_candidate_stabilization_docs_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/082_workspace_admin_contract_integration_completion_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/037_redesign_v2_architecture_review_decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `.worktrees/phase1c-ceo-office-first-slice/reviews/068_workspace_tenant_model_preference_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-FRONTEND-BATCH-1.md` | CURRENT IMPLEMENTATION ISSUE | Implemented / Review Required | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_runtime_materialization_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/XHS-WORKSPACE-INSTANCE-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_mode_contract_validation_compatibility_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_team_migration_transfer_gate_9b1_handoff_snapshot_fix_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_company_package_r3_provenance_closure_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260810_workspace_studio_blueprint_assembly_001.md` | UNKNOWN | Completed (Blueprint Draft assembly; Runtime gates open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260717_workspace_r3_artifact_project_status_closure.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260810_workspace_operating_cycle_closure_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/032_evolution_decision_evidence_reliability_boundaries.md` | UNKNOWN | verified by 质量运行席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_auto_progress_advance_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/RD-PHASE-2B-E2E-CLOSURE-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_scope_gate_8a1c_source_relation_contract_fix_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260730_global_assistant_runtime_v1.md` | UNKNOWN | CLOSED — PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_operating_v1_primary_two_cycle_e2e_001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/069_model_gateway_production_security_boundary.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/033_evolution_decision_evidence_map.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-TEAM-OPERATING-REAL-EMPLOYEE-E2E-001.md` | CURRENT | IMPLEMENTED / ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_three_business_workspace_ui_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/SHARED-BUSINESS-WORKSPACE-READ-MODEL-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-GLOBAL-UI-SEVEN-AREA-FINAL-ACCEPTANCE-001.md` | CURRENT / IMPLEMENTATION ISSUE | Review | IMPLEMENTED / ACCEPTED WITH RECORDED P2 — final CEO review required | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_manual_risk_escalation_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/045_runtime_role_wiring_first_slice.md` | UNKNOWN | Implementation accepted by 产品规划席 on 2026-07-07 (质量运行席 verification PASS, 48 test | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260717_workspace_r1_unified_runtime_baseline.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_operating_v1_phase3b_successor_control_001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_unified_token_cost_budget_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260719_workspace_startup_failure_signal_contract_fix.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_desktop_runtime_flow_001.md` | UNKNOWN | Completed (local flow; external release gates open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-UI-INDEPENDENT-DELIVERY-EPIC.md` | UNKNOWN | REVIEW — M1 CLOSED / M2 CLOSED / M2.5A CLOSED / M2.5B UI-HOLD / M3 SECURITY BLOC | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_ui_runtime_migration_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-WHOLE-APP-PRODUCT-GAP-CLOSURE-001.md` | CURRENT / IMPLEMENTATION ISSUE | Implemented / Accepted with Recorded P1 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-CANONICAL-EXECUTION-SCOPE-RECONCILIATION-001.md` | CURRENT / IMPLEMENTATION ISSUE | Review | IMPLEMENTED / ACCEPTED CANDIDATE — pending CEO / ChatGPT review | YES | explicit supersede wording found | YES |
| `issues/RD-PHASE-2B-ARTIFACT-REVIEW-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_desktop_runtime_simulation_001.md` | UNKNOWN | Completed (local browser gate; packaged Desktop revalidation open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_scope_gate_8a1a_refusal_response_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_scope_gate_8a3a_traceability_field_contract_fix_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_cross_surface_multi_work_runtime_proof_001.md` | CURRENT | Frozen | PROOF IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `issues/075_model_gateway_local_demo_release_candidate_gate.md` | UNKNOWN | "implemented" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/phase85_commercial_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260722_google_oidc_project_runtime_vertical_slice.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-M4-M5-CONTINUOUS-DELIVERY-001.md` | CURRENT IMPLEMENTATION ISSUE | Review — IMPLEMENTED / CEO IMPLEMENTATION REVIEW REQUIRED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_risk_gate_8b2_integrity_contract_alignment_fix_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/phase7_production_credential_vault_gate.md` | UNKNOWN | Draft for future security gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260722_macos_keychain_google_oidc_project_runtime.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_auto_progress_timeout_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260719_d1_toolchain_unfreeze_proposal.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-RESPONSIBILITY-ROUTING-RUNTIME-001.md` | CURRENT · IMPLEMENTATION | Implemented · Contract Alignment CEO Review Required | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/019_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | conducted by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/phase7_billing_usage_contract_gate.md` | UNKNOWN | Draft for cross-team gate review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/RD-WORKSPACE-INSTANCE-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_team_migration_transfer_gate_9b1_handoff_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260820_autonomous_operating_v1_implementation_001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/RD-PHASE-2B-P7-DECISION-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/070_model_gateway_runtime_secret_guardrails.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/phase55_admin_readiness_review.md` | UNKNOWN | review-only (零代码改动) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260719_workspace_startup_signal_coverage_gap_decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/022_ai_task_executor_mvp_release_candidate_stabilization_docs.md` | UNKNOWN | implemented by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-CANONICAL-USAGE-ATTRIBUTION-001.md` | CURRENT | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-EMPLOYEE-RECRUITMENT-AVATAR-CLOSURE-001.md` | CURRENT IMPLEMENTATION ISSUE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-VISUAL-BASELINE-REAL-PRODUCT-INTEGRATION-001.md` | CURRENT | AUDITED / IMPLEMENTATION BLOCKED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260722_project_runtime_page.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/062_adr0028_phase1_shared_contract.md` | UNKNOWN | "co-signed-with-conditions — 原 Curis Workspace 团队附 5 条件签收 (2026-07-08)" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-CONVERSATION-ATTENTION-LIFECYCLE-001.md` | CURRENT / IMPLEMENTATION ISSUE | Review | IMPLEMENTED / ACCEPTED WITH RECORDED FOLLOW-UP — core global Conversation productization verified; f | NO | explicit supersede wording found | NO / UNKNOWN |
| `issues/20260810_workspace_staffing_proposal_runtime_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_operating_v1_phase2_single_cycle_execution_001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_manual_takeover_request_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_operating_v1_phase3a_evaluation_decision_001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-ORGANIZATION-CENTER-PRODUCTIZATION-001.md` | CURRENT IMPLEMENTATION ISSUE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/014_sprint_3_role_context_runtime_reference_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-KNOWLEDGE-LIBRARY-PRODUCTIZATION-001.md` | CURRENT IMPLEMENTATION ISSUE | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `issues/20260719_d1_toolchain_unfreeze_implement.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260717_workspace_r2_asset_instantiation_closure.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260722_local_project_runtime_target_provisioning.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-MEETING-ROOM-PRODUCTIZATION-001.md` | CURRENT | Review | IMPLEMENTED / PARTIAL — CYCLE BUDGET LOCALLY VERIFIED; NEW LEGITIMATE EVENT REQUIRED FOR MULTI-CYCLE | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_real_rd_tool_e2e_candidate_selection.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260723_project_owner_workbench_product_flow.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `issues/CURIS-TEAM-OPERATING-UI-RUNTIME-E2E-001.md` | CURRENT · IMPLEMENTATION | Implemented · CEO Review Required | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_mode_contract_validation_sequence_isolation_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260729_business_department_org_model.md` | UNKNOWN | IMPLEMENTATION ACCEPTED / BLOCKED_L2 | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_hybrid_mode_handoff_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_operating_v1_evidence_bound_learning_001.md` | CURRENT | Review | IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `issues/087_phase35_admin_contract_review_employee_department_templates.md` | UNKNOWN | "APPROVE-WITH-CONDITIONS" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-GENERAL-WORKSPACE-P1-OPERATING-CLOSURE.md` | CURRENT / IMPLEMENTATION ISSUE | Implemented / Partial — Packaged native interaction gate remains | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_runtime_workspace_foundation_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-RELEASE-DISTRIBUTION-RECOVERY-001.md` | CURRENT / IMPLEMENTATION ISSUE | Implemented / Partial — Blocked at Signing / Notarization | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-M2.5-GENERAL-WORKSPACE-CONTEXT-001.md` | CURRENT / IMPLEMENTATION | IMPLEMENTED — M2.5A CLOSED / M2.5B UI-HOLD / CEO REVIEW REQUIRED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_runtime_api_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_desktop_runtime_execution_001.md` | UNKNOWN | Completed (runtime bridge; external execution evidence open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-TALENT-CAPABILITY-PRODUCTIZATION-001.md` | CURRENT IMPLEMENTATION ISSUE | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `issues/CURIS-V1-OPERATING-INTELLIGENCE-PRODUCTIZATION-001.md` | CURRENT IMPLEMENTATION ISSUE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_scope_gate_8a3b_sensitive_projection_contract_fix_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_workflow_mode_sequence_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/phase77_billing_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_runtime_first_arrival_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260810_workspace_capability_supply_review_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-V1-GENERAL-WORKSPACE-LIFECYCLE-CLOSURE-001.md` | CURRENT / IMPLEMENTATION ISSUE | Review | IMPLEMENTED / ACCEPTED — bounded lifecycle and native navigation/restart verified; global experience | NO | UNKNOWN | NO / UNKNOWN |
| `issues/031_evolution_decision_evidence_reliability_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_runtime_simulation_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260722_real_rd_container_runtime_prerequisite.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/phase1a_ai_company_runtime_foundation.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260722_workspace_product_flow_first_vertical_slice.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260810_workspace_staffing_simulation_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260820_canonical_business_spine_implementation_001.md` | UNKNOWN | IMPLEMENTED / ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_manual_stop_boundary_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/RD-PHASE-2B-HANDOFF-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260809_runtime_foundation_001.md` | UNKNOWN | Completed | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_canonical_child_work_foundation_001.md` | CURRENT | Frozen | IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_real_rd_tool_closure_prerequisite_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_scope_gate_8a1_source_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/phase5_g2_security_review_kickoff.md` | UNKNOWN | kickoff-draft | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/034_post_v0_1_execution_reliability_closeout_gate.md` | UNKNOWN | APPROVED by 总控决策席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_risk_gate_8b1_response_contract_alignment_decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/AGENT-COMPUTER-ACCESS-RUNTIME-P0-001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/WORKSPACE-ENGINEERING-MULTI-SURFACE-PACKAGE-001.md` | CURRENT · IMPLEMENTATION ISSUE | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/021_ai_task_executor_mvp_release_candidate_gate.md` | UNKNOWN | defined by 系统交付席 on 2026-07-06. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/015_sprint_3_role_context_runtime_reference_first_slice.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/CURIS-PHASE-B-P0-CORE-PRODUCT-RECONCILIATION-001.md` | IMPLEMENTATION ISSUE | Review | IMPLEMENTED / ACCEPTED CANDIDATE — pending CEO / ChatGPT review | YES | explicit supersede wording found | YES |
| `issues/20260809_desktop_runtime_workitem_001.md` | UNKNOWN | Completed (local runtime object creation; execution gates open) | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_operating_v1_cross_domain_contract_proof_001.md` | CURRENT | Review | IMPLEMENTED / ACCEPTED | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_mode_contract_validation_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_ai_secretary_closeout_gate_8c1_8a_8b_review_rollup_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260821_autonomous_operating_v1_phase1_control_persistence_001.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_mode_contract_validation_failclosed_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/085_workspace_admin_contract_integration_completion.md` | UNKNOWN | "done" | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/20260718_workspace_r4_unified_artifact_output_contract_gate.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/shared/20260717_admin_r3_e2e_handoff.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/shared/20260717_admin_workspace_stash_handoff.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `issues/shared/20260718_workspace_workbuddy_real_rd_tool_closure_status_sync.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_VISUAL_REEXPRESSION_TEST/CEO_REVIEW_NOTES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_FULL_VISUAL_EXPLORATION/DESIGN_NOTES.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_FULL_VISUAL_EXPLORATION/analytics-r5.js` | PROTOTYPE MOCK（候选合同的产品表达，不代表 Runtime 已支持） | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_FULL_VISUAL_EXPLORATION/data-r5.js` | PROTOTYPE MOCK（不是当前 Authority，不代表 Runtime 已支持） | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_FULL_VISUAL_EXPLORATION/_capture_ceo_review.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `CONTENT_GROWTH_FULL_VISUAL_EXPLORATION/production-work.js` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_ui_runtime_migration_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_sprint0_architecture_convergence_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_multi_project_session_recovery_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_workflow_context_budget_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_hybrid_mode_entry_switch_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_minimal_rd_toolset_implementation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase5_s8_rd_template_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a2c_logging_response_consistency_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase1_s2_workspace_model_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/002_tool_system_v1_6_meta_development_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_gateway_startup_evidence_preservation_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/029_evolution_decision_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_transfer_gate_9b2_fail_rollback_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/AGENT-COMPUTER-ACCESS-RUNTIME-P0-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_token_cost_budget_visibility_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_business_department_org_model_review.md` | UNKNOWN | `PASS（实现、迁移与回归） / BLOCKED_L2（真实成果正向 Browser 证据）` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_manual_risk_escalation_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/071_workspace_model_preference_local_e2e_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_shared_main_manual_merge_preparation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase4_s7_model_gateway_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_hybrid_mode_profile_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_d1_single_model_toolchain_entry_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260723_project_owner_workbench_product_flow_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_project_memory_recovery_b1_scope_key_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_exact_binding_scope_set_l2_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_scope_gate_9a1_owner_boundary_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_scope_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/008_sprint_2_unified_task_console_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_real_rd_tool_e2e_d1_tenant_reservation_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/074_workspace_company_foundation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_real_model_execution_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_scope_gate_9a3_exclusion_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/081_workspace_department_activation_ui_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260719_workspace_startup_failure_single_sentinel_diagnostic_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/SHARED-EMPLOYEE-EXECUTION-TRUST-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260730_digital_employee_execution_control_loop_v1_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/073_model_gateway_local_demo_release_closeout_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_runtime_simulation_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_p0_local_desktop_owner_review.md` | UNKNOWN | `PASS（Issue Scope） / BLOCKED（Workspace Full Regression）` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/RD-WORKSPACE-INSTANCE-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a2a_status_code_singleton_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_artifact_project_status_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_project_state_fact_source_a3_focused_validation_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/080_workspace_department_activation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_multi_project_session_seed_gap_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a1b_missing_context_refusal_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_minimal_rd_toolset_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_scope_gate_9a3_exclusion_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/016_sprint_4_multi_entry_ui_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/011_sprint_3_lightweight_role_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_8b2_source_integrity_tamper_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_remaining_role_employee_binding_set_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_transfer_gate_9b2_failure_check_matrix_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/033_local_demo_verification_automation_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/084_phase4_ai_employee_system_mvp_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_real_model_execution_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/RD-PHASE-2B-ARTIFACT-REVIEW-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/038_d1_runtime_role_wiring_boundary_verification.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/004_sprint_1_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/022_ai_task_executor_mvp_local_demo_release_verification_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase5_s10_knowledge_management_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_8b3_minimal_logging_visibility_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/007_sprint_2_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_remaining_six_model_calls_l2_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_project_memory_recovery_b3_compatibility_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_8b1_failure_blocking_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_pr2_post_merge_scope_governance_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/SHARED-EMPLOYEE-ORGANIZATION-PROJECTION-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_regression_stabilization_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/025_run_evidence_reliability_first_slice_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_closeout_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_workspace_regression_employee_templates_review.md` | UNKNOWN | `PASS` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a3b_sensitive_projection_contract_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/061_workspace_capability_integration_phase_1_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/023_ai_task_executor_mvp_v0_1_release_closeout_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/083_workspace_self_extension_mvp_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r1_unified_runtime_baseline_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_package_workflow_bridge_revocation_failclosed_fix_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_d1_selfuse_trusted_identity_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_company_package_provenance_membership_provisioning_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_p0_authentication_onboarding_review.md` | UNKNOWN | `BLOCKED_L2` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_package_workflow_versioned_bridge_implementation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase4_s6_capability_registry_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_ai_call_usage_ledger_foundation_review.md` | UNKNOWN | `PASS（Issue Scope）` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_scope_gate_9a2_artifact_scope_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_runtime_foundation_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `reviews/20260718_workspace_container_exit1_static_diagnostic_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/034_local_demo_api_smoke_helper_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a1a_refusal_response_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260810_ceo_workforce_experience_ui_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/027_workflow_error_fallback_evidence_map_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/012_sprint_3_role_profiles_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_mode_contract_validation_compatibility_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260731_curis_product_blueprint_v1_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_remaining_workflow_completion_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/BACKEND-TEST-DB-SAFETY-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/026_workflow_error_fallback_observability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/017_ai_task_executor_mvp_readiness_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/PRESERVED-MIXED-SOURCE-INTEGRATION-BASELINE-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260722_local_project_runtime_target_provisioning_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_scope_gate_9a2_canonical_manifest_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/SHARED-EMPLOYEE-WORK-AREA-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_remaining_six_model_calls_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260719_d1_unfreeze_qa.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/070_workspace_model_preference_ui_review.md` | UNKNOWN | READY_FOR_QUALITY_VERIFICATION | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_company_package_provenance_isolated_setup_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/031_local_demo_operator_polish_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/069_workspace_tenant_model_preference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/WORKSPACE-ENGINEERING-P0-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/020_ai_task_executor_mvp_release_candidate_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/003_tool_system_v1_8_controlled_self_evolution_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_tenant_identity_membership_implementation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/010_project_memory_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/015_sprint_4_multi_entry_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260722_real_rd_container_runtime_prerequisite_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/067_model_gateway_runtime_secret_guardrails_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/WORKSPACE-ENGINEERING-P15-TRANSACTIONAL-MIGRATION-001_review.md` | UNKNOWN | ACCEPTED — BOUNDED REVERSIBLE RENAME MIGRATION ONLY | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/024_post_v0_1_execution_reliability_boundaries_review.md` | UNKNOWN | PASS by 质量运行席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/063_workspace_official_model_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_items_1_7_code_construction_audit_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260731_curis_product_blueprint_v1_rereview.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a2c_logging_response_consistency_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a1a_source_object_field_map_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/014_role_context_runtime_reference_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/072_model_gateway_local_demo_release_candidate_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_admin_company_package_workflow_provenance_l2_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/006_sprint_1_ceo_readable_visualization_polish_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260719_workspace_startup_failure_deterministic_evidence_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_8b1_response_contract_alignment_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_d1_selfuse_trusted_provisioning_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_transfer_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_manual_stop_boundary_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/078_workspace_department_catalog_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_multi_project_session_scope_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_runtime_materialization_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/075_workspace_company_foundation_first_slice_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_workflow_mode_entry_guard_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_real_rd_tool_e2e_d1_tenant_reservation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260730_global_assistant_live_model_validation_review.md` | UNKNOWN | COMPLETED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/WORKSPACE-ENGINEERING-P1-PACKAGE-LIFECYCLE-001_review.md` | UNKNOWN | ACCEPTED — SCHEMA-STABLE SUBSTRATE ONLY | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_scope_gate_9a2_artifact_scope_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260719_workspace_startup_entry_wrapper_minimal_implementation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/065_new_api_local_deployment_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase5_s9_content_template_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/062_workspace_model_gateway_adapter_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/085_phase4_ai_employee_system_rc_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_trusted_ceo_usage_context_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260730_integration_candidate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase3_s5_task_execution_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/028_evolution_decision_evidence_reliability_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a3b_sensitive_projection_contract_fix_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260719_workspace_pinned_online_build_postbuild_sentinel_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260722_project_runtime_page_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/079_workspace_department_activation_boundaries_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_artifact_output_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_workflow_context_budget_l2_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase6_s11_basic_memory_context_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_8b2_integrity_contract_alignment_fix_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/066_model_gateway_production_security_boundary_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_runtime_first_arrival_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/009_project_memory_foundation_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a3c_no_execute_side_effect_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/030_post_v0_1_execution_reliability_closeout_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a3a_traceability_whitelist_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_d1_entry_owner_role_claim_fix_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_token_cost_budget_projection_failclosed_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase2_s3_ai_employee_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_hybrid_mode_handoff_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_exact_binding_scope_set_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_trusted_ceo_usage_context_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_transfer_gate_9b3_sensitive_artifact_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a1c_source_mismatch_isolation_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/SHARED-BUSINESS-WORKSPACE-READ-MODEL-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_artifact_project_status_closure_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_8b3_minimal_logging_visibility_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_trusted_ceo_usage_context_l2_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_artifact_output_backend_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/032_local_demo_operator_release_notes_package_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/019_chinese_operation_console_localization_review.md` | UNKNOWN | READY FOR PRODUCT ACCEPTANCE | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a2b_cross_tenant_mismatch_lock_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_container_exit1_static_diagnostic_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_company_package_provenance_real_execution_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_ai_rd_vertical_e2e_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/001_sprint_0_acceptance_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase3_s4_project_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/064_workspace_official_tool_catalog_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_mode_contract_validation_failclosed_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_token_cost_budget_closeout_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_transfer_gate_9b1_handoff_snapshot_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_agent_mode_entry_criteria_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_runtime_workspace_foundation_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_real_model_execution_dns_https_egress_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260730_global_assistant_runtime_v1_review.md` | UNKNOWN | FAILED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/XHS-WORKSPACE-INSTANCE-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_d1_single_model_toolchain_entry_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_project_memory_recovery_b2_recovery_runbook_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_ceo_mapping_migration_input_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_workflow_mode_sequence_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_transfer_gate_9b1_handoff_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_freellmapi_owner_only_experimental_gateway_review.md` | UNKNOWN | `PASS（本地契约与回归） / BLOCKED_L2（Owner 真实调用）` | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a3b_sensitive_field_filter_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/005_sprint_1_visualization_first_slice_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/076_workspace_company_foundation_local_demo_evidence_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/035_project_memory_execution_summary_boundaries_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_d1_entry_owner_role_claim_fix_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_manual_takeover_stop_risk_escalation_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260722_macos_keychain_google_oidc_project_runtime_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_artifact_output_closeout_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/RD-PHASE-2B-E2E-CLOSURE-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a1c_source_relation_contract_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a1a_source_refusal_status_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_real_rd_tool_closure_prerequisite_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/036_project_memory_execution_summary_review.md` | UNKNOWN | accepted by 产品规划席. | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_remaining_role_employee_binding_set_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/RD-PHASE-2B-HANDOFF-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_three_business_workspace_ui_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/RD-PHASE-2B-P7-DECISION-001_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/018_ai_task_executor_mvp_readiness_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_mode_contract_validation_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/013_role_context_runtime_reference_architecture_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_multi_project_session_context_switch_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a3a_traceability_field_contract_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase1_s1_app_shell_design_system_review.md` | UNKNOWN | PASS | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/WORKSPACE-ENGINEERING-P05-COMPANY-INTEGRATION-001_review.md` | UNKNOWN | Formal Acceptance Record / IMPLEMENTED / ACCEPTED | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260809_runtime_api_001_review.md` | UNKNOWN | Review | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_selfuse_official_workflow_bridge_compatibility_fix_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_tenant_identity_membership_implementation_security_boundary_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_gateway_startup_evidence_preservation_security_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r2_asset_instantiation_closure_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/077_workspace_company_department_catalog_summary_review.md` | UNKNOWN | READY_FOR_QUALITY_RECHECK | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/021_ai_task_executor_mvp_release_candidate_stabilization_docs_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_token_cost_budget_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_unified_output_cross_tenant_visibility_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260719_workspace_startup_stage_signal_minimal_implementation_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_mode_contract_validation_sequence_isolation_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260719_workspace_startup_failure_signal_controlled_revert_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_agent_mode_failclosed_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/082_workspace_admin_contract_integration_completion_review.md` | UNKNOWN | ACCEPTED_BY_PRODUCT | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260717_workspace_r3_real_model_execution_architecture_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | explicit supersede wording found | NO / UNKNOWN |
| `reviews/20260719_workspace_admin_warning_suppression_minimal_fix_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260729_mvp_phase6_s12_experience_convergence_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_risk_gate_8b2_integrity_contract_alignment_fix_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/037_redesign_v2_architecture_review_decision.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_manual_takeover_request_contract_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_auto_progress_timeout_retry_recovery_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_team_migration_transfer_gate_9b3_sensitive_artifact_security_review.md` | UNKNOWN | mapped | blocked | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/068_workspace_tenant_model_preference_boundaries_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
| `reviews/20260718_workspace_r4_ai_secretary_scope_gate_8a1a_source_visibility_state_filter_gate_review.md` | UNKNOWN | UNKNOWN | UNKNOWN | NO | UNKNOWN | NO / UNKNOWN |
